import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { InsertActivity, UserRole } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // Add route to update a user's active account type
  app.patch("/api/user/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    
    // Only allow updating the logged-in user
    if (!req.isAuthenticated() || req.user.id !== id) {
      return res.status(403).send("Unauthorized");
    }
    
    const { activeAccountType } = req.body;
    
    // Verify that the user has access to this account type
    if (activeAccountType) {
      const user = await storage.getUser(id);
      if (!user) return res.status(404).send("User not found");
      
      // Check if the account type is in the user's list of available types
      const availableTypes = user.accountTypes?.split(',') || [user.accountType];
      if (!availableTypes.includes(activeAccountType)) {
        return res.status(400).send("Invalid account type");
      }
    }
    
    const updatedUser = await storage.updateUser(id, { activeAccountType });
    if (!updatedUser) return res.status(404).send("User not found");
    
    res.json(updatedUser);
  });

  // Set up file upload
  const uploadDir = path.join(process.cwd(), 'uploads');
  
  // Ensure uploads directory exists
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }
  
  const storage_config = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, uniqueSuffix + path.extname(file.originalname));
    }
  });
  
  const upload = multer({ storage: storage_config });
  
  // Authorization middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };
  
  // Role-based authorization middleware
  const requireRole = (roles: string[]) => {
    return (req: any, res: any, next: any) => {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      if (!roles.includes(req.user.role)) {
        return res.status(403).json({ message: "Insufficient permissions" });
      }
      next();
    };
  };
  
  // Helper to create activities
  const createActivity = async (
    type: string, 
    details: any, 
    userId: number, 
    clubId?: number, 
    leagueId?: number
  ) => {
    const activity: InsertActivity = {
      type,
      details,
      userId,
      clubId,
      leagueId
    };
    
    return await storage.createActivity(activity);
  };

  // Club routes
  app.get("/api/clubs", requireAuth, async (req, res) => {
    try {
      const clubs = await storage.getAllClubs();
      res.json(clubs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch clubs" });
    }
  });
  
  app.get("/api/user/clubs", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const clubs = await storage.getUserClubs(userId);
      res.json(clubs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user clubs" });
    }
  });
  
  app.post("/api/clubs", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const club = await storage.createClub({
        ...req.body,
        createdById: userId
      });
      
      await createActivity('club_create', { clubName: club.name }, userId, club.id);
      
      res.status(201).json(club);
    } catch (error) {
      res.status(500).json({ message: "Failed to create club" });
    }
  });
  
  app.get("/api/clubs/:id", requireAuth, async (req, res) => {
    try {
      const club = await storage.getClub(Number(req.params.id));
      if (!club) {
        return res.status(404).json({ message: "Club not found" });
      }
      res.json(club);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch club" });
    }
  });
  
  app.get("/api/clubs/:id/members", requireAuth, async (req, res) => {
    try {
      const members = await storage.getClubMembers(Number(req.params.id));
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch club members" });
    }
  });
  
  app.post("/api/clubs/:id/members", requireAuth, async (req, res) => {
    try {
      const clubId = Number(req.params.id);
      const userId = req.body.userId;
      
      const club = await storage.getClub(clubId);
      if (!club) {
        return res.status(404).json({ message: "Club not found" });
      }
      
      const membership = await storage.addClubMember({
        userId,
        clubId,
        isAdmin: false
      });
      
      const user = await storage.getUser(userId);
      await createActivity(
        'club_member_add', 
        { memberName: `${user?.firstName} ${user?.lastName}` }, 
        (req.user as any).id,
        clubId
      );
      
      res.status(201).json(membership);
    } catch (error) {
      res.status(500).json({ message: "Failed to add club member" });
    }
  });
  
  // League routes
  app.get("/api/leagues", requireAuth, async (req, res) => {
    try {
      const leagues = await storage.getAllLeagues();
      res.json(leagues);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch leagues" });
    }
  });
  
  app.post("/api/leagues", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const league = await storage.createLeague({
        ...req.body,
        createdById: userId
      });
      
      await createActivity('league_create', { leagueName: league.name }, userId, null, league.id);
      
      res.status(201).json(league);
    } catch (error) {
      res.status(500).json({ message: "Failed to create league" });
    }
  });
  
  app.get("/api/leagues/:id", requireAuth, async (req, res) => {
    try {
      const league = await storage.getLeague(Number(req.params.id));
      if (!league) {
        return res.status(404).json({ message: "League not found" });
      }
      res.json(league);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch league" });
    }
  });
  
  // Team routes
  app.get("/api/clubs/:clubId/teams", requireAuth, async (req, res) => {
    try {
      const teams = await storage.getClubTeams(Number(req.params.clubId));
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teams" });
    }
  });
  
  app.post("/api/clubs/:clubId/teams", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const clubId = Number(req.params.clubId);
      
      const team = await storage.createTeam({
        ...req.body,
        clubId,
        createdById: userId
      });
      
      await createActivity(
        'team_create', 
        { teamName: team.name, clubId }, 
        userId, 
        clubId,
        team.leagueId
      );
      
      res.status(201).json(team);
    } catch (error) {
      res.status(500).json({ message: "Failed to create team" });
    }
  });
  
  // Document routes
  app.get("/api/documents", requireAuth, async (req, res) => {
    try {
      const documents = await storage.getAllDocuments();
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });
  
  app.post("/api/documents", requireAuth, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const userId = (req.user as any).id;
      const filePath = `/uploads/${req.file.filename}`;
      
      const document = await storage.createDocument({
        name: req.body.name || req.file.originalname,
        type: path.extname(req.file.originalname).substring(1),
        path: filePath,
        uploadedById: userId,
        clubId: req.body.clubId ? Number(req.body.clubId) : null,
        leagueId: req.body.leagueId ? Number(req.body.leagueId) : null,
        isPublic: req.body.isPublic === 'true'
      });
      
      await createActivity(
        'document_upload', 
        { documentName: document.name }, 
        userId, 
        document.clubId || undefined,
        document.leagueId || undefined
      );
      
      res.status(201).json(document);
    } catch (error) {
      res.status(500).json({ message: "Failed to upload document" });
    }
  });
  
  app.get("/api/documents/:id", requireAuth, async (req, res) => {
    try {
      const document = await storage.getDocument(Number(req.params.id));
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      res.json(document);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch document" });
    }
  });
  
  // Meeting routes
  app.get("/api/meetings", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const meetings = await storage.getUserMeetings(userId);
      res.json(meetings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch meetings" });
    }
  });
  
  app.get("/api/meetings/upcoming", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const meetings = await storage.getUpcomingMeetings(userId);
      res.json(meetings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch upcoming meetings" });
    }
  });
  
  app.post("/api/meetings", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      
      const meeting = await storage.createMeeting({
        ...req.body,
        hostId: userId
      });
      
      // Add participants
      if (req.body.participants && Array.isArray(req.body.participants)) {
        for (const participantId of req.body.participants) {
          await storage.addMeetingParticipant({
            meetingId: meeting.id,
            userId: participantId,
            status: 'invited'
          });
        }
      }
      
      await createActivity(
        'meeting_schedule', 
        { meetingTitle: meeting.title, startTime: meeting.startTime }, 
        userId, 
        meeting.clubId || undefined,
        meeting.leagueId || undefined
      );
      
      res.status(201).json(meeting);
    } catch (error) {
      res.status(500).json({ message: "Failed to create meeting" });
    }
  });
  
  app.get("/api/meetings/:id/participants", requireAuth, async (req, res) => {
    try {
      const participants = await storage.getMeetingParticipants(Number(req.params.id));
      res.json(participants);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch meeting participants" });
    }
  });
  
  // Message routes
  app.get("/api/messages/:channelId", requireAuth, async (req, res) => {
    try {
      const messages = await storage.getChannelMessages(req.params.channelId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  
  // Activity routes
  app.get("/api/activities/recent", requireAuth, async (req, res) => {
    try {
      const activities = await storage.getRecentActivities();
      
      // Get user information for each activity
      const activitiesWithUsers = await Promise.all(
        activities.map(async (activity) => {
          const user = await storage.getUser(activity.userId);
          return {
            ...activity,
            user: user ? {
              id: user.id,
              firstName: user.firstName,
              lastName: user.lastName,
              username: user.username
            } : null
          };
        })
      );
      
      res.json(activitiesWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent activities" });
    }
  });
  
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Set up WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws) => {
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'chat') {
          // Store message in database
          const newMessage = await storage.createMessage({
            content: data.content,
            senderId: data.senderId,
            channelId: data.channelId
          });
          
          // Get sender info
          const sender = await storage.getUser(data.senderId);
          
          // Broadcast to all connected clients
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'chat',
                message: {
                  ...newMessage,
                  sender: sender ? {
                    id: sender.id,
                    firstName: sender.firstName,
                    lastName: sender.lastName
                  } : null
                }
              }));
            }
          });
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
  });

  return httpServer;
}
