import { users, type User, type InsertUser, clubs, type Club, type InsertClub, 
  clubMemberships, type ClubMembership, type InsertClubMembership,
  leagues, type League, type InsertLeague, teams, type Team, type InsertTeam,
  documents, type Document, type InsertDocument, meetings, type Meeting, type InsertMeeting,
  meetingParticipants, type MeetingParticipant, type InsertMeetingParticipant,
  messages, type Message, type InsertMessage, activities, type Activity, type InsertActivity,
  UserRole, type UserRoleType, AccountType, type AccountTypeType } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";
import { hashPassword } from "./auth";

// Define the storage interface with all CRUD methods
export interface IStorage {
  // Session store
  sessionStore: session.Store;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;
  
  // Club methods
  getClub(id: number): Promise<Club | undefined>;
  getAllClubs(): Promise<Club[]>;
  getUserClubs(userId: number): Promise<Club[]>;
  createClub(club: InsertClub): Promise<Club>;
  updateClub(id: number, club: Partial<Club>): Promise<Club | undefined>;
  deleteClub(id: number): Promise<boolean>;
  
  // Club membership methods
  getClubMembership(userId: number, clubId: number): Promise<ClubMembership | undefined>;
  getClubMembers(clubId: number): Promise<User[]>;
  addClubMember(membership: InsertClubMembership): Promise<ClubMembership>;
  removeClubMember(userId: number, clubId: number): Promise<boolean>;
  updateClubMembership(userId: number, clubId: number, isAdmin: boolean): Promise<ClubMembership | undefined>;
  getClubMemberCount(clubId: number): Promise<number>;
  
  // League methods
  getLeague(id: number): Promise<League | undefined>;
  getAllLeagues(): Promise<League[]>;
  getUserLeagues(userId: number): Promise<League[]>;
  createLeague(league: InsertLeague): Promise<League>;
  updateLeague(id: number, league: Partial<League>): Promise<League | undefined>;
  deleteLeague(id: number): Promise<boolean>;
  
  // Team methods
  getTeam(id: number): Promise<Team | undefined>;
  getClubTeams(clubId: number): Promise<Team[]>;
  getLeagueTeams(leagueId: number): Promise<Team[]>;
  createTeam(team: InsertTeam): Promise<Team>;
  updateTeam(id: number, team: Partial<Team>): Promise<Team | undefined>;
  deleteTeam(id: number): Promise<boolean>;
  
  // Document methods
  getDocument(id: number): Promise<Document | undefined>;
  getAllDocuments(): Promise<Document[]>;
  getUserDocuments(userId: number): Promise<Document[]>;
  getClubDocuments(clubId: number): Promise<Document[]>;
  getLeagueDocuments(leagueId: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  deleteDocument(id: number): Promise<boolean>;
  
  // Meeting methods
  getMeeting(id: number): Promise<Meeting | undefined>;
  getAllMeetings(): Promise<Meeting[]>;
  getUserMeetings(userId: number): Promise<Meeting[]>;
  getUpcomingMeetings(userId: number): Promise<Meeting[]>;
  createMeeting(meeting: InsertMeeting): Promise<Meeting>;
  updateMeeting(id: number, meeting: Partial<Meeting>): Promise<Meeting | undefined>;
  deleteMeeting(id: number): Promise<boolean>;
  
  // Meeting participant methods
  addMeetingParticipant(participant: InsertMeetingParticipant): Promise<MeetingParticipant>;
  removeMeetingParticipant(meetingId: number, userId: number): Promise<boolean>;
  updateMeetingParticipantStatus(meetingId: number, userId: number, status: string): Promise<MeetingParticipant | undefined>;
  getMeetingParticipants(meetingId: number): Promise<User[]>;
  
  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getChannelMessages(channelId: string): Promise<Message[]>;
  
  // Activity methods
  createActivity(activity: InsertActivity): Promise<Activity>;
  getUserActivities(userId: number): Promise<Activity[]>;
  getClubActivities(clubId: number): Promise<Activity[]>;
  getRecentActivities(): Promise<Activity[]>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private clubs: Map<number, Club>;
  private clubMemberships: Map<string, ClubMembership>; // `${userId}-${clubId}`
  private leagues: Map<number, League>;
  private teams: Map<number, Team>;
  private documents: Map<number, Document>;
  private meetings: Map<number, Meeting>;
  private meetingParticipants: Map<string, MeetingParticipant>; // `${meetingId}-${userId}`
  private messages: Map<number, Message>;
  private activities: Map<number, Activity>;
  
  public sessionStore: session.Store;
  
  private userIdCounter: number;
  private clubIdCounter: number;
  private clubMembershipIdCounter: number;
  private leagueIdCounter: number;
  private teamIdCounter: number;
  private documentIdCounter: number;
  private meetingIdCounter: number;
  private meetingParticipantIdCounter: number;
  private messageIdCounter: number;
  private activityIdCounter: number;

  constructor() {
    this.users = new Map();
    this.clubs = new Map();
    this.clubMemberships = new Map();
    this.leagues = new Map();
    this.teams = new Map();
    this.documents = new Map();
    this.meetings = new Map();
    this.meetingParticipants = new Map();
    this.messages = new Map();
    this.activities = new Map();
    
    this.userIdCounter = 1;
    this.clubIdCounter = 1;
    this.clubMembershipIdCounter = 1;
    this.leagueIdCounter = 1;
    this.teamIdCounter = 1;
    this.documentIdCounter = 1;
    this.meetingIdCounter = 1;
    this.meetingParticipantIdCounter = 1;
    this.messageIdCounter = 1;
    this.activityIdCounter = 1;
    
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Create demo accounts
    this.createDemoAccounts();
  }
  
  /**
   * Creates demo accounts for testing and demonstration purposes
   */
  private async createDemoAccounts() {
    // Check if demo accounts already exist to avoid duplicates
    const playerExists = await this.getUserByUsername('player');
    const clubExists = await this.getUserByUsername('club');
    const adminExists = await this.getUserByUsername('admin');
    const multiExists = await this.getUserByUsername('multi');
    
    // Create demo player account
    if (!playerExists) {
      await this.createUser({
        username: 'player',
        password: await hashPassword('player123'),
        firstName: 'John',
        lastName: 'Player',
        email: 'player@example.com',
        role: UserRole.MEMBER,
        accountType: AccountType.PLAYER,
        accountTypes: AccountType.PLAYER,
        activeAccountType: AccountType.PLAYER
      });
      console.log('Created demo player account');
    }
    
    // Create demo club account
    if (!clubExists) {
      await this.createUser({
        username: 'club',
        password: await hashPassword('club123'),
        firstName: 'Jane',
        lastName: 'Club',
        email: 'club@example.com',
        role: UserRole.CLUB_ADMIN,
        accountType: AccountType.CLUB,
        accountTypes: AccountType.CLUB,
        activeAccountType: AccountType.CLUB
      });
      console.log('Created demo club account');
    }
    
    // Create demo admin account
    if (!adminExists) {
      await this.createUser({
        username: 'admin',
        password: await hashPassword('admin123'),
        firstName: 'Admin',
        lastName: 'User',
        email: 'admin@example.com',
        role: UserRole.NATIONAL_STAFF,
        accountType: AccountType.USA_ADMIN,
        accountTypes: AccountType.USA_ADMIN,
        activeAccountType: AccountType.USA_ADMIN
      });
      console.log('Created demo admin account');
    }
    
    // Create multi-role account
    if (!multiExists) {
      await this.createUser({
        username: 'multi',
        password: await hashPassword('multi123'),
        firstName: 'Multi',
        lastName: 'User',
        email: 'multi@example.com',
        role: UserRole.NATIONAL_STAFF, // Highest privilege
        accountType: AccountType.PLAYER, // Default view
        accountTypes: `${AccountType.PLAYER},${AccountType.CLUB},${AccountType.USA_ADMIN}`,
        activeAccountType: AccountType.PLAYER
      });
      console.log('Created multi-role demo account');
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    
    // Set default values for required fields
    let role: UserRoleType = UserRole.MEMBER;
    if (insertUser.role && Object.values(UserRole).includes(insertUser.role as any)) {
      role = insertUser.role as UserRoleType;
    }
    
    let accountType: AccountTypeType = AccountType.PLAYER;
    if (insertUser.accountType && Object.values(AccountType).includes(insertUser.accountType as any)) {
      accountType = insertUser.accountType as AccountTypeType;
    }
    
    let activeAccountType: AccountTypeType = accountType;
    if (insertUser.activeAccountType && Object.values(AccountType).includes(insertUser.activeAccountType as any)) {
      activeAccountType = insertUser.activeAccountType as AccountTypeType;
    }
    
    // Handle accountTypes - either use the provided value, or use accountType as the default
    const accountTypes = insertUser.accountTypes || accountType;
    
    // Create the user with properly typed fields
    const user: User = {
      id,
      username: insertUser.username,
      password: insertUser.password,
      firstName: insertUser.firstName,
      lastName: insertUser.lastName,
      email: insertUser.email,
      role,
      accountType,
      accountTypes,
      activeAccountType
    };
    
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  // Club methods
  async getClub(id: number): Promise<Club | undefined> {
    return this.clubs.get(id);
  }

  async getAllClubs(): Promise<Club[]> {
    return Array.from(this.clubs.values());
  }

  async getUserClubs(userId: number): Promise<Club[]> {
    const memberships = Array.from(this.clubMemberships.values())
      .filter(membership => membership.userId === userId);
    
    return memberships.map(membership => this.clubs.get(membership.clubId))
      .filter((club): club is Club => club !== undefined);
  }

  async createClub(insertClub: InsertClub): Promise<Club> {
    const id = this.clubIdCounter++;
    const club: Club = { 
      ...insertClub, 
      id,
      createdAt: new Date() 
    };
    this.clubs.set(id, club);
    
    // Automatically add creator as admin
    await this.addClubMember({
      userId: club.createdById,
      clubId: id,
      isAdmin: true
    });
    
    return club;
  }

  async updateClub(id: number, clubData: Partial<Club>): Promise<Club | undefined> {
    const club = this.clubs.get(id);
    if (!club) return undefined;
    
    const updatedClub = { ...club, ...clubData };
    this.clubs.set(id, updatedClub);
    return updatedClub;
  }

  async deleteClub(id: number): Promise<boolean> {
    return this.clubs.delete(id);
  }
  
  // Club membership methods
  async getClubMembership(userId: number, clubId: number): Promise<ClubMembership | undefined> {
    return this.clubMemberships.get(`${userId}-${clubId}`);
  }

  async getClubMembers(clubId: number): Promise<User[]> {
    const membershipIds = Array.from(this.clubMemberships.values())
      .filter(membership => membership.clubId === clubId)
      .map(membership => membership.userId);
    
    return membershipIds.map(id => this.users.get(id))
      .filter((user): user is User => user !== undefined);
  }

  async addClubMember(insertMembership: InsertClubMembership): Promise<ClubMembership> {
    const id = this.clubMembershipIdCounter++;
    const membership: ClubMembership = { 
      ...insertMembership, 
      id,
      joinedAt: new Date() 
    };
    this.clubMemberships.set(`${membership.userId}-${membership.clubId}`, membership);
    return membership;
  }

  async removeClubMember(userId: number, clubId: number): Promise<boolean> {
    return this.clubMemberships.delete(`${userId}-${clubId}`);
  }

  async updateClubMembership(userId: number, clubId: number, isAdmin: boolean): Promise<ClubMembership | undefined> {
    const key = `${userId}-${clubId}`;
    const membership = this.clubMemberships.get(key);
    if (!membership) return undefined;
    
    const updatedMembership = { ...membership, isAdmin };
    this.clubMemberships.set(key, updatedMembership);
    return updatedMembership;
  }

  async getClubMemberCount(clubId: number): Promise<number> {
    return Array.from(this.clubMemberships.values())
      .filter(membership => membership.clubId === clubId).length;
  }
  
  // League methods
  async getLeague(id: number): Promise<League | undefined> {
    return this.leagues.get(id);
  }

  async getAllLeagues(): Promise<League[]> {
    return Array.from(this.leagues.values());
  }

  async getUserLeagues(userId: number): Promise<League[]> {
    // Get clubs where user is a member
    const userClubIds = Array.from(this.clubMemberships.values())
      .filter(membership => membership.userId === userId)
      .map(membership => membership.clubId);
    
    // Get leagues created by user or associated with user's clubs
    return Array.from(this.leagues.values())
      .filter(league => 
        league.createdById === userId || 
        userClubIds.some(clubId => 
          Array.from(this.teams.values())
            .some(team => team.clubId === clubId && team.leagueId === league.id)
        )
      );
  }

  async createLeague(insertLeague: InsertLeague): Promise<League> {
    const id = this.leagueIdCounter++;
    const league: League = { 
      ...insertLeague, 
      id,
      createdAt: new Date() 
    };
    this.leagues.set(id, league);
    return league;
  }

  async updateLeague(id: number, leagueData: Partial<League>): Promise<League | undefined> {
    const league = this.leagues.get(id);
    if (!league) return undefined;
    
    const updatedLeague = { ...league, ...leagueData };
    this.leagues.set(id, updatedLeague);
    return updatedLeague;
  }

  async deleteLeague(id: number): Promise<boolean> {
    return this.leagues.delete(id);
  }
  
  // Team methods
  async getTeam(id: number): Promise<Team | undefined> {
    return this.teams.get(id);
  }

  async getClubTeams(clubId: number): Promise<Team[]> {
    return Array.from(this.teams.values())
      .filter(team => team.clubId === clubId);
  }

  async getLeagueTeams(leagueId: number): Promise<Team[]> {
    return Array.from(this.teams.values())
      .filter(team => team.leagueId === leagueId);
  }

  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const id = this.teamIdCounter++;
    const team: Team = { 
      ...insertTeam, 
      id,
      createdAt: new Date() 
    };
    this.teams.set(id, team);
    return team;
  }

  async updateTeam(id: number, teamData: Partial<Team>): Promise<Team | undefined> {
    const team = this.teams.get(id);
    if (!team) return undefined;
    
    const updatedTeam = { ...team, ...teamData };
    this.teams.set(id, updatedTeam);
    return updatedTeam;
  }

  async deleteTeam(id: number): Promise<boolean> {
    return this.teams.delete(id);
  }
  
  // Document methods
  async getDocument(id: number): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getAllDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values());
  }

  async getUserDocuments(userId: number): Promise<Document[]> {
    return Array.from(this.documents.values())
      .filter(doc => doc.uploadedById === userId || doc.isPublic);
  }

  async getClubDocuments(clubId: number): Promise<Document[]> {
    return Array.from(this.documents.values())
      .filter(doc => doc.clubId === clubId);
  }

  async getLeagueDocuments(leagueId: number): Promise<Document[]> {
    return Array.from(this.documents.values())
      .filter(doc => doc.leagueId === leagueId);
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.documentIdCounter++;
    const document: Document = { 
      ...insertDocument, 
      id,
      uploadedAt: new Date() 
    };
    this.documents.set(id, document);
    return document;
  }

  async deleteDocument(id: number): Promise<boolean> {
    return this.documents.delete(id);
  }
  
  // Meeting methods
  async getMeeting(id: number): Promise<Meeting | undefined> {
    return this.meetings.get(id);
  }

  async getAllMeetings(): Promise<Meeting[]> {
    return Array.from(this.meetings.values());
  }

  async getUserMeetings(userId: number): Promise<Meeting[]> {
    // Get meetings where user is a participant
    const meetingIds = Array.from(this.meetingParticipants.values())
      .filter(participant => participant.userId === userId)
      .map(participant => participant.meetingId);
    
    // Also include meetings hosted by the user
    return Array.from(this.meetings.values())
      .filter(meeting => 
        meetingIds.includes(meeting.id) || 
        meeting.hostId === userId
      );
  }

  async getUpcomingMeetings(userId: number): Promise<Meeting[]> {
    const now = new Date();
    const userMeetings = await this.getUserMeetings(userId);
    
    return userMeetings.filter(meeting => new Date(meeting.startTime) > now)
      .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
  }

  async createMeeting(insertMeeting: InsertMeeting): Promise<Meeting> {
    const id = this.meetingIdCounter++;
    const meeting: Meeting = { 
      ...insertMeeting, 
      id,
      createdAt: new Date() 
    };
    this.meetings.set(id, meeting);
    
    // Automatically add host as participant
    await this.addMeetingParticipant({
      meetingId: id,
      userId: meeting.hostId,
      status: 'accepted'
    });
    
    return meeting;
  }

  async updateMeeting(id: number, meetingData: Partial<Meeting>): Promise<Meeting | undefined> {
    const meeting = this.meetings.get(id);
    if (!meeting) return undefined;
    
    const updatedMeeting = { ...meeting, ...meetingData };
    this.meetings.set(id, updatedMeeting);
    return updatedMeeting;
  }

  async deleteMeeting(id: number): Promise<boolean> {
    return this.meetings.delete(id);
  }
  
  // Meeting participant methods
  async addMeetingParticipant(insertParticipant: InsertMeetingParticipant): Promise<MeetingParticipant> {
    const id = this.meetingParticipantIdCounter++;
    const participant: MeetingParticipant = { ...insertParticipant, id };
    this.meetingParticipants.set(`${participant.meetingId}-${participant.userId}`, participant);
    return participant;
  }

  async removeMeetingParticipant(meetingId: number, userId: number): Promise<boolean> {
    return this.meetingParticipants.delete(`${meetingId}-${userId}`);
  }

  async updateMeetingParticipantStatus(meetingId: number, userId: number, status: string): Promise<MeetingParticipant | undefined> {
    const key = `${meetingId}-${userId}`;
    const participant = this.meetingParticipants.get(key);
    if (!participant) return undefined;
    
    const updatedParticipant = { ...participant, status };
    this.meetingParticipants.set(key, updatedParticipant);
    return updatedParticipant;
  }

  async getMeetingParticipants(meetingId: number): Promise<User[]> {
    const participantIds = Array.from(this.meetingParticipants.values())
      .filter(participant => participant.meetingId === meetingId)
      .map(participant => participant.userId);
    
    return participantIds.map(id => this.users.get(id))
      .filter((user): user is User => user !== undefined);
  }
  
  // Message methods
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const message: Message = { 
      ...insertMessage, 
      id,
      sentAt: new Date() 
    };
    this.messages.set(id, message);
    return message;
  }

  async getChannelMessages(channelId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.channelId === channelId)
      .sort((a, b) => new Date(a.sentAt).getTime() - new Date(b.sentAt).getTime());
  }
  
  // Activity methods
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const activity: Activity = { 
      ...insertActivity, 
      id,
      createdAt: new Date() 
    };
    this.activities.set(id, activity);
    return activity;
  }

  async getUserActivities(userId: number): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getClubActivities(clubId: number): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.clubId === clubId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getRecentActivities(): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 10);
  }
}

export const storage = new MemStorage();
