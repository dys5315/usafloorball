import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User roles enum
export const UserRole = {
  MEMBER: "member",
  CLUB_ADMIN: "club_admin",
  NATIONAL_STAFF: "national_staff",
} as const;

export type UserRoleType = typeof UserRole[keyof typeof UserRole];

// Account types enum
export const AccountType = {
  PLAYER: "player",
  CLUB: "club",
  USA_ADMIN: "usa_admin",
} as const;

export type AccountTypeType = typeof AccountType[keyof typeof AccountType];

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").$type<UserRoleType>().notNull().default(UserRole.MEMBER),
  accountType: text("account_type").$type<AccountTypeType>().notNull().default(AccountType.PLAYER),
  // A comma-separated list of account types the user has access to
  accountTypes: text("account_types").default(""),
  // The currently active account type
  activeAccountType: text("active_account_type").$type<AccountTypeType>().default(AccountType.PLAYER),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Clubs table
export const clubs = pgTable("clubs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  createdById: integer("created_by_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertClubSchema = createInsertSchema(clubs).omit({ id: true, createdAt: true });
export type InsertClub = z.infer<typeof insertClubSchema>;
export type Club = typeof clubs.$inferSelect;

// Club memberships table
export const clubMemberships = pgTable("club_memberships", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  clubId: integer("club_id").notNull(),
  isAdmin: boolean("is_admin").notNull().default(false),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

export const insertClubMembershipSchema = createInsertSchema(clubMemberships).omit({ id: true, joinedAt: true });
export type InsertClubMembership = z.infer<typeof insertClubMembershipSchema>;
export type ClubMembership = typeof clubMemberships.$inferSelect;

// Leagues table
export const leagues = pgTable("leagues", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  createdById: integer("created_by_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertLeagueSchema = createInsertSchema(leagues).omit({ id: true, createdAt: true });
export type InsertLeague = z.infer<typeof insertLeagueSchema>;
export type League = typeof leagues.$inferSelect;

// Teams table
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  clubId: integer("club_id").notNull(),
  leagueId: integer("league_id"),
  createdById: integer("created_by_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTeamSchema = createInsertSchema(teams).omit({ id: true, createdAt: true });
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teams.$inferSelect;

// Documents table
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  path: text("path").notNull(),
  uploadedById: integer("uploaded_by_id").notNull(),
  clubId: integer("club_id"),
  leagueId: integer("league_id"),
  isPublic: boolean("is_public").notNull().default(false),
  uploadedAt: timestamp("uploaded_at").notNull().defaultNow(),
});

export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true, uploadedAt: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

// Meetings table
export const meetings = pgTable("meetings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  platform: text("platform").notNull(), // 'zoom', 'teams', etc.
  link: text("link").notNull(),
  hostId: integer("host_id").notNull(),
  clubId: integer("club_id"),
  leagueId: integer("league_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMeetingSchema = createInsertSchema(meetings).omit({ id: true, createdAt: true });
export type InsertMeeting = z.infer<typeof insertMeetingSchema>;
export type Meeting = typeof meetings.$inferSelect;

// Meeting participants table
export const meetingParticipants = pgTable("meeting_participants", {
  id: serial("id").primaryKey(),
  meetingId: integer("meeting_id").notNull(),
  userId: integer("user_id").notNull(),
  status: text("status").notNull().default("invited"), // 'invited', 'accepted', 'declined'
});

export const insertMeetingParticipantSchema = createInsertSchema(meetingParticipants).omit({ id: true });
export type InsertMeetingParticipant = z.infer<typeof insertMeetingParticipantSchema>;
export type MeetingParticipant = typeof meetingParticipants.$inferSelect;

// Messages table for chat
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  senderId: integer("sender_id").notNull(),
  channelId: text("channel_id").notNull(), // 'club-{id}', 'league-{id}', etc.
  sentAt: timestamp("sent_at").notNull().defaultNow(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, sentAt: true });
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Activity table
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'document_upload', 'club_create', 'meeting_schedule', etc.
  details: jsonb("details").notNull(),
  userId: integer("user_id").notNull(),
  clubId: integer("club_id"),
  leagueId: integer("league_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertActivitySchema = createInsertSchema(activities).omit({ id: true, createdAt: true });
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;
