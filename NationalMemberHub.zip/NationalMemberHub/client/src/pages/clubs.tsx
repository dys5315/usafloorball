import { MainLayout } from "@/components/layout/main-layout";
import { ClubList } from "@/components/clubs/club-list";

export default function Clubs() {
  return (
    <MainLayout>
      <ClubList />
    </MainLayout>
  );
}
