import { MainLayout } from "@/components/layout/main-layout";
import { MemberList } from "@/components/members/member-list";

export default function Members() {
  return (
    <MainLayout>
      <MemberList />
    </MainLayout>
  );
}
