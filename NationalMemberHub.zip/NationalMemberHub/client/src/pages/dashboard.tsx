import { useAuth } from "@/hooks/use-auth";
import { AccountType } from "@shared/schema";
import PlayerDashboard from "./dashboards/player-dashboard";
import ClubDashboard from "./dashboards/club-dashboard";
import AdminDashboard from "./dashboards/admin-dashboard";
import { Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Dashboard() {
  const { user, isLoading } = useAuth();
  const [availableAccountTypes, setAvailableAccountTypes] = useState<string[]>([]);
  const [isChangingType, setIsChangingType] = useState(false);

  useEffect(() => {
    if (user && user.accountTypes) {
      const types = user.accountTypes.split(',').filter(Boolean);
      setAvailableAccountTypes(types);
    } else if (user) {
      setAvailableAccountTypes([user.accountType]);
    }
  }, [user]);

  const handleAccountTypeChange = async (newType: string) => {
    if (!user || !newType || newType === user.activeAccountType) return;
    
    setIsChangingType(true);
    
    try {
      // Update the user's active account type
      const res = await apiRequest("PATCH", `/api/user/${user.id}`, {
        activeAccountType: newType
      });
      
      const updatedUser = await res.json();
      queryClient.setQueryData(["/api/user"], updatedUser);
    } catch (error) {
      console.error("Failed to update account type:", error);
    } finally {
      setIsChangingType(false);
    }
  };

  if (isLoading || isChangingType) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    // This shouldn't happen since the route is protected, but just in case
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-xl">Please log in to view your dashboard</div>
      </div>
    );
  }

  // If user has multiple account types, show account switcher
  const showAccountSwitcher = availableAccountTypes.length > 1;
  const activeAccountType = user.activeAccountType || user.accountType;

  // Helper to get display name for account type
  const getAccountTypeName = (type: string) => {
    return type === AccountType.PLAYER ? "Player" :
           type === AccountType.CLUB ? "Club" :
           type === AccountType.USA_ADMIN ? "USA Admin" : type;
  };

  // Header with account type tabs (if applicable)
  const AccountHeader = () => {
    if (!showAccountSwitcher) return null;
    
    return (
      <div className="bg-white border-b p-4 mb-6">
        <div className="container max-w-7xl mx-auto">
          <h2 className="text-lg font-medium mb-4">Switch Account Type</h2>
          <Tabs 
            value={activeAccountType} 
            onValueChange={handleAccountTypeChange}
            className="w-full"
          >
            <TabsList className="grid" style={{ gridTemplateColumns: `repeat(${availableAccountTypes.length}, 1fr)` }}>
              {availableAccountTypes.map((type) => (
                <TabsTrigger key={type} value={type} className="text-sm">
                  {getAccountTypeName(type)}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>
      </div>
    );
  };

  // Render the appropriate dashboard based on active account type
  const renderDashboard = () => {
    switch (activeAccountType) {
      case AccountType.PLAYER:
        return <PlayerDashboard />;
      case AccountType.CLUB:
        return <ClubDashboard />;
      case AccountType.USA_ADMIN:
        return <AdminDashboard />;
      default:
        // Default to player dashboard as fallback
        return <PlayerDashboard />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <AccountHeader />
      {renderDashboard()}
    </div>
  );
}