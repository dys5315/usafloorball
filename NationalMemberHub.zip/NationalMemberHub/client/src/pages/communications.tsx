import { MainLayout } from "@/components/layout/main-layout";
import { Chat } from "@/components/communications/chat";

export default function Communications() {
  return (
    <MainLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold">Communications</h1>
        <p className="text-neutral-500">Chat and communicate with your organization</p>
      </div>
      
      <Chat />
    </MainLayout>
  );
}
