import { MainLayout } from "@/components/layout/main-layout";
import { DocumentList } from "@/components/documents/document-list";

export default function Documents() {
  return (
    <MainLayout>
      <DocumentList />
    </MainLayout>
  );
}
