import { MainLayout } from "@/components/layout/main-layout";
import { MeetingList } from "@/components/meetings/meeting-list";

export default function Meetings() {
  return (
    <MainLayout>
      <MeetingList />
    </MainLayout>
  );
}
