import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UsersRound, ClipboardList, MessageSquare, Calendar, Trophy, FileText } from "lucide-react";

export default function ClubDashboard() {
  const { user } = useAuth();

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Welcome, {user?.firstName}!</h1>
        <p className="text-lg text-muted-foreground">Club Administration Dashboard</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Club Members</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">154</div>
          </CardContent>
          <CardFooter>
            <UsersRound className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">12 new this month</span>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Teams</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
          </CardContent>
          <CardFooter>
            <UsersRound className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">2 leagues</span>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
          </CardContent>
          <CardFooter>
            <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">This week</span>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
          </CardContent>
          <CardFooter>
            <ClipboardList className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">3 urgent</span>
          </CardFooter>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Recent Club Activity</CardTitle>
            <CardDescription>Updates from your club</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4 pb-4 border-b">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Membership Forms Updated</p>
                  <p className="text-sm text-muted-foreground">New season registration forms have been uploaded.</p>
                </div>
                <div className="text-xs text-muted-foreground">2h ago</div>
              </div>
              <div className="flex items-start gap-4 pb-4 border-b">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Summer Tournament Registration</p>
                  <p className="text-sm text-muted-foreground">Registration is now open for the summer tournament.</p>
                </div>
                <div className="text-xs text-muted-foreground">1d ago</div>
              </div>
              <div className="flex items-start gap-4 pb-4 border-b">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">New Coaching Staff</p>
                  <p className="text-sm text-muted-foreground">Two new coaches have joined our club.</p>
                </div>
                <div className="text-xs text-muted-foreground">3d ago</div>
              </div>
              <div className="flex items-start gap-4">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Field Maintenance Schedule</p>
                  <p className="text-sm text-muted-foreground">Updated maintenance schedule for all club fields.</p>
                </div>
                <div className="text-xs text-muted-foreground">5d ago</div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm">View All Activity</Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common club management tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Button className="w-full justify-start" variant="outline">
                <UsersRound className="h-4 w-4 mr-2" />
                Manage Members
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Event
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <MessageSquare className="h-4 w-4 mr-2" />
                Send Announcement
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <FileText className="h-4 w-4 mr-2" />
                Upload Document
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <Trophy className="h-4 w-4 mr-2" />
                League Management
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Meetings</CardTitle>
            <CardDescription>Next week's scheduled meetings</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-4 border-b">
                <div>
                  <h4 className="font-semibold">Coaches Meeting</h4>
                  <div className="text-sm text-muted-foreground">Strategy planning</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">Apr 3, 2025</div>
                  <div className="text-sm text-muted-foreground">6:00 PM</div>
                </div>
              </div>
              <div className="flex items-center justify-between pb-4 border-b">
                <div>
                  <h4 className="font-semibold">Parent Information Session</h4>
                  <div className="text-sm text-muted-foreground">Season kickoff</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">Apr 7, 2025</div>
                  <div className="text-sm text-muted-foreground">7:00 PM</div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold">Board Meeting</h4>
                  <div className="text-sm text-muted-foreground">Monthly update</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">Apr 10, 2025</div>
                  <div className="text-sm text-muted-foreground">8:00 PM</div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm">Schedule Meeting</Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Documents</CardTitle>
            <CardDescription>Recently updated club documents</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4 pb-4 border-b">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">2025_Registration_Form.pdf</p>
                  <p className="text-xs text-muted-foreground">Updated 2 days ago</p>
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <FileText className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-start gap-4 pb-4 border-b">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">Club_Bylaws_2025.docx</p>
                  <p className="text-xs text-muted-foreground">Updated 1 week ago</p>
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <FileText className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-start gap-4">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">Season_Schedule.xlsx</p>
                  <p className="text-xs text-muted-foreground">Updated 2 weeks ago</p>
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <FileText className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm">View All Documents</Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}