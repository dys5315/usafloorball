import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, Users, Trophy, CalendarDays, FileText, Activity, Settings, BarChart, Network, LogOut } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, lazy, Suspense } from "react";
import { useLocation } from "wouter";

// Import committee dashboards
import CompetitionDashboard from "@/components/admin/committee-dashboards/competition-dashboard";
import DevelopmentDashboard from "@/components/admin/committee-dashboards/development-dashboard";
import MeetingManager from "@/components/admin/meeting-manager";

// Use React.lazy to handle the ForceGraph component
const CommitteeNetwork = lazy(() => import('@/components/admin/committee-network'));

export default function AdminDashboard() {
  const { user, logoutMutation } = useAuth();
  const [activeCommittee, setActiveCommittee] = useState("overview");
  const [_, navigate] = useLocation();

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Welcome, {user?.firstName}!</h1>
        <p className="text-lg text-muted-foreground">National Administration Dashboard</p>
      </div>

      <Tabs 
        defaultValue="overview" 
        value={activeCommittee} 
        onValueChange={setActiveCommittee}
        className="mb-8"
      >
        <div className="border-b">
          <TabsList className="mb-0 justify-start w-full overflow-x-auto">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="competition">Competition</TabsTrigger>
            <TabsTrigger value="development">Development</TabsTrigger>
            <TabsTrigger value="finance">Finance</TabsTrigger>
            <TabsTrigger value="governance">Governance</TabsTrigger>
            <TabsTrigger value="marcom">Marcom</TabsTrigger>
            <TabsTrigger value="membership">Membership</TabsTrigger>
            <TabsTrigger value="national-teams">National Teams</TabsTrigger>
            <TabsTrigger value="special-olympics">Special Olympics</TabsTrigger>
            <TabsTrigger value="meetings">Meetings</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="overview" className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Clubs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">238</div>
              </CardContent>
              <CardFooter>
                <Building2 className="h-4 w-4 mr-1 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">5 new this month</span>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Registered Players</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12,456</div>
              </CardContent>
              <CardFooter>
                <Users className="h-4 w-4 mr-1 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">+324 this month</span>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Active Leagues</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">42</div>
              </CardContent>
              <CardFooter>
                <Trophy className="h-4 w-4 mr-1 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Across 15 states</span>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">National Events</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8</div>
              </CardContent>
              <CardFooter>
                <CalendarDays className="h-4 w-4 mr-1 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Upcoming this quarter</span>
              </CardFooter>
            </Card>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Committee Network</CardTitle>
              <CardDescription>Interactive visualization of committee relationships and responsibilities</CardDescription>
            </CardHeader>
            <CardContent>
              <Suspense fallback={<div className="h-[500px] flex items-center justify-center"><div className="text-center"><p>Loading network visualization...</p></div></div>}>
                <CommitteeNetwork />
              </Suspense>
            </CardContent>
            <CardFooter className="flex justify-between">
              <p className="text-sm text-muted-foreground">Click on nodes or connections for more information</p>
              <Button variant="outline" size="sm">
                <Network className="h-4 w-4 mr-2" />
                View Details
              </Button>
            </CardFooter>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-7 gap-6 mb-6">
            <Card className="lg:col-span-4">
              <CardHeader>
                <CardTitle>Growth Metrics</CardTitle>
                <CardDescription>Membership growth over the past year</CardDescription>
              </CardHeader>
              <CardContent className="h-80 flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <BarChart className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <p>Player registration growth chart</p>
                  <p className="text-sm">(Analytics visualization would appear here)</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" size="sm">View Detailed Analytics</Button>
              </CardFooter>
            </Card>

            <Card className="lg:col-span-3">
              <CardHeader>
                <CardTitle>Admin Quick Actions</CardTitle>
                <CardDescription>National level administrative tasks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button className="w-full justify-start" variant="outline">
                    <Building2 className="h-4 w-4 mr-2" />
                    Manage Clubs & Organizations
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <Trophy className="h-4 w-4 mr-2" />
                    National Competition Setup
                  </Button>
                  <Button className="w-full justify-start" variant="outline" onClick={() => setActiveCommittee("meetings")}>
                    <CalendarDays className="h-4 w-4 mr-2" />
                    Meeting Center
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <FileText className="h-4 w-4 mr-2" />
                    Policy & Document Management
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <Activity className="h-4 w-4 mr-2" />
                    Compliance Monitoring
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Policy Updates</CardTitle>
                <CardDescription>Latest governing documents and policies</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-4 pb-4 border-b">
                    <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium">2025 National Competition Guidelines</p>
                      <p className="text-xs text-muted-foreground">Updated March 25, 2025</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 pb-4 border-b">
                    <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium">Coach Certification Requirements</p>
                      <p className="text-xs text-muted-foreground">Updated March 15, 2025</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 pb-4 border-b">
                    <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium">Player Transfer Policy</p>
                      <p className="text-xs text-muted-foreground">Updated March 10, 2025</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium">National Safety Protocol</p>
                      <p className="text-xs text-muted-foreground">Updated March 1, 2025</p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" size="sm">Manage Policies</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Upcoming National Events</CardTitle>
                <CardDescription>Major events on the calendar</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-4 border-b">
                    <div>
                      <h4 className="font-semibold">National Championship</h4>
                      <div className="text-sm text-muted-foreground">Chicago, IL</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">June 15-20, 2025</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pb-4 border-b">
                    <div>
                      <h4 className="font-semibold">Coaches Convention</h4>
                      <div className="text-sm text-muted-foreground">Dallas, TX</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">July 8-10, 2025</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pb-4 border-b">
                    <div>
                      <h4 className="font-semibold">Regional Tournaments</h4>
                      <div className="text-sm text-muted-foreground">Multiple Locations</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">May 1-30, 2025</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold">Annual Board Meeting</h4>
                      <div className="text-sm text-muted-foreground">Virtual</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">April 22, 2025</div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" size="sm">Event Management</Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="competition" className="pt-6">
          <CompetitionDashboard />
        </TabsContent>

        <TabsContent value="development" className="pt-6">
          <DevelopmentDashboard />
        </TabsContent>

        <TabsContent value="finance" className="pt-6">
          <div className="flex flex-col items-center justify-center space-y-4 py-12">
            <Settings className="h-16 w-16 text-muted-foreground" />
            <h3 className="text-xl font-medium">Finance Committee Dashboard</h3>
            <p className="text-muted-foreground text-center max-w-md">
              This committee dashboard is under development. Check back soon for budget management tools, financial reporting, and expense tracking features.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="governance" className="pt-6">
          <div className="flex flex-col items-center justify-center space-y-4 py-12">
            <Settings className="h-16 w-16 text-muted-foreground" />
            <h3 className="text-xl font-medium">Governance Committee Dashboard</h3>
            <p className="text-muted-foreground text-center max-w-md">
              This committee dashboard is under development. Check back soon for bylaw management, policy creation, and compliance monitoring tools.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="marcom" className="pt-6">
          <div className="flex flex-col items-center justify-center space-y-4 py-12">
            <Settings className="h-16 w-16 text-muted-foreground" />
            <h3 className="text-xl font-medium">Marketing & Communications Committee Dashboard</h3>
            <p className="text-muted-foreground text-center max-w-md">
              This committee dashboard is under development. Check back soon for social media management, brand asset library, and campaign analytics tools.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="membership" className="pt-6">
          <div className="flex flex-col items-center justify-center space-y-4 py-12">
            <Settings className="h-16 w-16 text-muted-foreground" />
            <h3 className="text-xl font-medium">Membership Committee Dashboard</h3>
            <p className="text-muted-foreground text-center max-w-md">
              This committee dashboard is under development. Check back soon for membership analytics, retention strategies, and growth initiative tracking.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="national-teams" className="pt-6">
          <div className="flex flex-col items-center justify-center space-y-4 py-12">
            <Settings className="h-16 w-16 text-muted-foreground" />
            <h3 className="text-xl font-medium">National Teams Committee Dashboard</h3>
            <p className="text-muted-foreground text-center max-w-md">
              This committee dashboard is under development. Check back soon for team selection tools, international competition management, and performance analytics.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="special-olympics" className="pt-6">
          <div className="flex flex-col items-center justify-center space-y-4 py-12">
            <Settings className="h-16 w-16 text-muted-foreground" />
            <h3 className="text-xl font-medium">Special Olympics Committee Dashboard</h3>
            <p className="text-muted-foreground text-center max-w-md">
              This committee dashboard is under development. Check back soon for inclusive program management, event coordination, and accessibility resources.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="meetings" className="pt-6">
          <MeetingManager />
        </TabsContent>
      </Tabs>

      {/* Logout Button positioned in the bottom right corner */}
      <div className="fixed bottom-6 right-6">
        <Button 
          variant="destructive" 
          onClick={() => {
            if (confirm("Are you sure you want to log out?")) {
              logoutMutation.mutate();
            }
          }}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </Button>
      </div>
    </div>
  );
}