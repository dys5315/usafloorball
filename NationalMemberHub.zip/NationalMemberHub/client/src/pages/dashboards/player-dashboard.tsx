import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarDays, Users, FileText, Award } from "lucide-react";

export default function PlayerDashboard() {
  const { user } = useAuth();

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Welcome, {user?.firstName}!</h1>
        <p className="text-lg text-muted-foreground">Your player dashboard</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">My Teams</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
          </CardContent>
          <CardFooter>
            <Users className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Active membership</span>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Leagues</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
          </CardContent>
          <CardFooter>
            <Award className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Current competition</span>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Practice Sessions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4</div>
          </CardContent>
          <CardFooter>
            <CalendarDays className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Upcoming this week</span>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Documents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
          </CardContent>
          <CardFooter>
            <FileText className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Permission forms & waivers</span>
          </CardFooter>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Matches</CardTitle>
              <CardDescription>Your scheduled games for the next two weeks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-4 border-b">
                  <div>
                    <h4 className="font-semibold">Regional Tournament - Round 1</h4>
                    <div className="text-sm text-muted-foreground">vs. Eastside Strikers</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">Apr 5, 2025</div>
                    <div className="text-sm text-muted-foreground">2:30 PM</div>
                  </div>
                </div>
                <div className="flex items-center justify-between pb-4 border-b">
                  <div>
                    <h4 className="font-semibold">League Match</h4>
                    <div className="text-sm text-muted-foreground">vs. Westfield United</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">Apr 12, 2025</div>
                    <div className="text-sm text-muted-foreground">1:00 PM</div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold">Exhibition Game</h4>
                    <div className="text-sm text-muted-foreground">vs. Riverside FC</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">Apr 19, 2025</div>
                    <div className="text-sm text-muted-foreground">11:00 AM</div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" size="sm">View All Games</Button>
            </CardFooter>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Practice Schedule</CardTitle>
              <CardDescription>Regular team practices</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-4 border-b">
                  <div className="font-medium">Mondays</div>
                  <div>5:30 PM - 7:30 PM</div>
                </div>
                <div className="flex items-center justify-between pb-4 border-b">
                  <div className="font-medium">Wednesdays</div>
                  <div>5:30 PM - 7:30 PM</div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="font-medium">Saturdays</div>
                  <div>9:00 AM - 11:00 AM</div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" size="sm">Season Calendar</Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}