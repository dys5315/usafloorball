import { MainLayout } from "@/components/layout/main-layout";
import { LeagueList } from "@/components/leagues/league-list";

export default function Leagues() {
  return (
    <MainLayout>
      <LeagueList />
    </MainLayout>
  );
}
