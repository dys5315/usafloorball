import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  Home, 
  FileText, 
  MessageSquare, 
  Video, 
  Users, 
  Trophy, 
  UserPlus, 
  Settings, 
  HelpCircle, 
  X 
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  isOpen: boolean;
  closeSidebar: () => void;
}

export function Sidebar({ isOpen, closeSidebar }: SidebarProps) {
  const { user } = useAuth();
  const [location, setLocation] = useState("");
  const [, navigate] = useLocation();

  // Update active menu item based on current location
  useEffect(() => {
    const path = window.location.hash || "#dashboard";
    setLocation(path.substring(1));
  }, []);

  const navigateTo = (path: string) => {
    setLocation(path);
    navigate(`/${path === "dashboard" ? "" : path}`);
    if (window.innerWidth < 1024) {
      closeSidebar();
    }
  };

  const getUserInitials = () => {
    if (!user) return "?";
    return `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`;
  };

  const getUserRoleLabel = () => {
    switch (user?.role) {
      case "club_admin":
        return "Club Admin";
      case "national_staff":
        return "National Staff";
      default:
        return "Member";
    }
  };

  return (
    <aside 
      className={cn(
        "bg-primary w-64 flex-shrink-0 overflow-y-auto transition-all duration-300 ease-in-out",
        "transform lg:translate-x-0 fixed lg:relative z-20 h-full text-primary-foreground",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}
    >
      <div className="p-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Avatar className="w-10 h-10 bg-background">
              <AvatarFallback className="text-primary font-medium">
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <p className="font-medium">{user?.firstName} {user?.lastName}</p>
              <p className="text-xs opacity-80">{getUserRoleLabel()}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="lg:hidden text-primary-foreground hover:bg-primary/90"
            onClick={closeSidebar}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <nav>
          <ul className="space-y-1">
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start px-4 py-2 rounded-lg text-primary-foreground hover:bg-primary/90 transition-colors duration-150",
                  location === "dashboard" && "bg-primary/90 font-medium"
                )}
                onClick={() => navigateTo("dashboard")}
              >
                <Home className="mr-3 h-5 w-5" />
                <span>Dashboard</span>
              </Button>
            </li>
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start px-4 py-2 rounded-lg text-primary-foreground hover:bg-primary/90 transition-colors duration-150",
                  location === "documents" && "bg-primary/90 font-medium"
                )}
                onClick={() => navigateTo("documents")}
              >
                <FileText className="mr-3 h-5 w-5" />
                <span>Documents</span>
              </Button>
            </li>
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start px-4 py-2 rounded-lg text-primary-foreground hover:bg-primary/90 transition-colors duration-150",
                  location === "communications" && "bg-primary/90 font-medium"
                )}
                onClick={() => navigateTo("communications")}
              >
                <MessageSquare className="mr-3 h-5 w-5" />
                <span>Communications</span>
              </Button>
            </li>
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start px-4 py-2 rounded-lg text-primary-foreground hover:bg-primary/90 transition-colors duration-150",
                  location === "meetings" && "bg-primary/90 font-medium"
                )}
                onClick={() => navigateTo("meetings")}
              >
                <Video className="mr-3 h-5 w-5" />
                <span>Meetings</span>
              </Button>
            </li>
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start px-4 py-2 rounded-lg text-primary-foreground hover:bg-primary/90 transition-colors duration-150",
                  location === "clubs" && "bg-primary/90 font-medium"
                )}
                onClick={() => navigateTo("clubs")}
              >
                <Users className="mr-3 h-5 w-5" />
                <span>Clubs</span>
              </Button>
            </li>
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start px-4 py-2 rounded-lg text-primary-foreground hover:bg-primary/90 transition-colors duration-150",
                  location === "leagues" && "bg-primary/90 font-medium"
                )}
                onClick={() => navigateTo("leagues")}
              >
                <Trophy className="mr-3 h-5 w-5" />
                <span>Leagues</span>
              </Button>
            </li>
            <li>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start px-4 py-2 rounded-lg text-primary-foreground hover:bg-primary/90 transition-colors duration-150",
                  location === "members" && "bg-primary/90 font-medium"
                )}
                onClick={() => navigateTo("members")}
              >
                <UserPlus className="mr-3 h-5 w-5" />
                <span>Members</span>
              </Button>
            </li>
          </ul>
          
          <div className="mt-6 pt-6 border-t border-primary/30">
            <ul className="space-y-1">
              <li>
                <Button
                  variant="ghost"
                  className="w-full justify-start px-4 py-2 rounded-lg text-primary-foreground hover:bg-primary/90 transition-colors duration-150"
                  onClick={() => navigateTo("settings")}
                >
                  <Settings className="mr-3 h-5 w-5" />
                  <span>Settings</span>
                </Button>
              </li>
              <li>
                <Button
                  variant="ghost"
                  className="w-full justify-start px-4 py-2 rounded-lg text-primary-foreground hover:bg-primary/90 transition-colors duration-150"
                  onClick={() => navigateTo("help")}
                >
                  <HelpCircle className="mr-3 h-5 w-5" />
                  <span>Help & Support</span>
                </Button>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </aside>
  );
}
