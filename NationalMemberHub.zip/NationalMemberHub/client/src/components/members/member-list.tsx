import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Search,
  User,
  Users,
  UserPlus,
  Mail,
  Shield,
  Filter,
} from "lucide-react";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import { UserRole } from "@shared/schema";

interface User {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
}

export function MemberList() {
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<string | null>(null);
  
  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    queryFn: getQueryFn({ on401: "throw" })
  });

  const getRoleBadge = (role: string) => {
    switch (role) {
      case UserRole.NATIONAL_STAFF:
        return <Badge className="bg-primary-100 text-primary-700 hover:bg-primary-200">National Staff</Badge>;
      case UserRole.CLUB_ADMIN:
        return <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-200">Club Admin</Badge>;
      default:
        return <Badge className="bg-neutral-100 text-neutral-700 hover:bg-neutral-200">Member</Badge>;
    }
  };

  const getUserInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`;
  };

  const getRandomColor = (userId: number) => {
    const colors = [
      "bg-red-200 text-red-700",
      "bg-blue-200 text-blue-700",
      "bg-green-200 text-green-700",
      "bg-yellow-200 text-yellow-700",
      "bg-purple-200 text-purple-700",
      "bg-pink-200 text-pink-700",
      "bg-indigo-200 text-indigo-700",
    ];
    return colors[userId % colors.length];
  };

  const filteredUsers = users
    ? users
        .filter(user => 
          (user.firstName.toLowerCase() + " " + user.lastName.toLowerCase()).includes(searchQuery.toLowerCase()) &&
          (roleFilter === null || user.role === roleFilter)
        )
        .sort((a, b) => a.lastName.localeCompare(b.lastName))
    : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Members</h1>
          <p className="text-neutral-500">Manage your organization's membership</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
            <Input
              placeholder="Search members..."
              className="pl-9 w-full sm:w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                {roleFilter ? `Filter: ${roleFilter.replace('_', ' ')}` : "Filter by role"}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => setRoleFilter(null)}>
                All roles
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setRoleFilter(UserRole.MEMBER)}>
                Members
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setRoleFilter(UserRole.CLUB_ADMIN)}>
                Club Admins
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setRoleFilter(UserRole.NATIONAL_STAFF)}>
                National Staff
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button className="gap-2">
            <UserPlus className="h-4 w-4" />
            Invite Member
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>Organization Members</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <MemberListSkeleton />
          ) : filteredUsers.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-6 text-center">
              <Users className="h-12 w-12 text-neutral-300 mb-4" />
              <h3 className="text-lg font-medium">No members found</h3>
              <p className="text-neutral-500 mb-4">
                {searchQuery || roleFilter ? "No members match your search criteria" : "Invite members to get started"}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[600px] text-left text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="py-3 px-4 font-medium">Member</th>
                    <th className="py-3 px-4 font-medium">Email</th>
                    <th className="py-3 px-4 font-medium">Role</th>
                    <th className="py-3 px-4 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map(user => (
                    <tr key={user.id} className="border-b">
                      <td className="py-3 px-4">
                        <div className="flex items-center">
                          <Avatar className={`h-8 w-8 mr-2 ${getRandomColor(user.id)}`}>
                            <AvatarFallback className="text-sm">
                              {getUserInitials(user.firstName, user.lastName)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{user.firstName} {user.lastName}</p>
                            <p className="text-xs text-neutral-500">@{user.username}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-neutral-600">{user.email}</td>
                      <td className="py-3 px-4">{getRoleBadge(user.role)}</td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <User className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Mail className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Shield className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function MemberListSkeleton() {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[600px] text-left text-sm">
        <thead>
          <tr className="border-b">
            <th className="py-3 px-4 font-medium">Member</th>
            <th className="py-3 px-4 font-medium">Email</th>
            <th className="py-3 px-4 font-medium">Role</th>
            <th className="py-3 px-4 font-medium">Actions</th>
          </tr>
        </thead>
        <tbody>
          {Array.from({ length: 5 }).map((_, i) => (
            <tr key={i} className="border-b">
              <td className="py-3 px-4">
                <div className="flex items-center">
                  <Skeleton className="h-8 w-8 rounded-full mr-2" />
                  <div>
                    <Skeleton className="h-4 w-24 mb-1" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
              </td>
              <td className="py-3 px-4">
                <Skeleton className="h-4 w-32" />
              </td>
              <td className="py-3 px-4">
                <Skeleton className="h-5 w-20 rounded-full" />
              </td>
              <td className="py-3 px-4">
                <div className="flex gap-2">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-8 w-8 rounded-full" />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
