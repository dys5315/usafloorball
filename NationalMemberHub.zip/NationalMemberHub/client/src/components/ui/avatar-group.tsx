import React from "react";
import { Avatar, AvatarFallback } from "./avatar";

type AvatarGroupProps = {
  users: {
    id: number;
    firstName?: string;
    lastName?: string;
    initials?: string;
  }[];
  max?: number;
};

export function AvatarGroup({ users, max = 3 }: AvatarGroupProps) {
  const visibleUsers = users.slice(0, max);
  const remainingCount = users.length - max;

  const getInitials = (user: {
    firstName?: string;
    lastName?: string;
    initials?: string;
  }) => {
    if (user.initials) return user.initials;
    if (user.firstName && user.lastName) {
      return `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`;
    }
    return "?";
  };

  const getRandomColor = (userId: number) => {
    const colors = [
      "bg-red-200 text-red-700",
      "bg-blue-200 text-blue-700",
      "bg-green-200 text-green-700",
      "bg-yellow-200 text-yellow-700",
      "bg-purple-200 text-purple-700",
      "bg-pink-200 text-pink-700",
      "bg-indigo-200 text-indigo-700",
    ];
    return colors[userId % colors.length];
  };

  return (
    <div className="flex -space-x-1">
      {visibleUsers.map((user) => (
        <Avatar key={user.id} className={`w-6 h-6 border border-white ${getRandomColor(user.id)}`}>
          <AvatarFallback className="text-xs">{getInitials(user)}</AvatarFallback>
        </Avatar>
      ))}
      
      {remainingCount > 0 && (
        <Avatar className="w-6 h-6 border border-white bg-neutral-200 text-neutral-700">
          <AvatarFallback className="text-xs">+{remainingCount}</AvatarFallback>
        </Avatar>
      )}
    </div>
  );
}
