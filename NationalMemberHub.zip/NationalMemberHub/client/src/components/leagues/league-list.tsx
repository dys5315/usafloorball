import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { format } from "date-fns";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

import {
  Trophy,
  Plus,
  Search,
  Calendar,
  Flag,
  Users,
  Clock,
} from "lucide-react";

interface League {
  id: number;
  name: string;
  description: string;
  startDate: string | null;
  endDate: string | null;
  createdById: number;
  createdAt: string;
}

const leagueFormSchema = z.object({
  name: z.string().min(3, "League name must be at least 3 characters"),
  description: z.string().optional(),
  startDate: z.string().optional().nullable(),
  endDate: z.string().optional().nullable(),
});

type LeagueFormValues = z.infer<typeof leagueFormSchema>;

export function LeagueList() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: leagues, isLoading } = useQuery<League[]>({
    queryKey: ["/api/leagues"],
    queryFn: getQueryFn({ on401: "throw" })
  });

  const createLeagueMutation = useMutation({
    mutationFn: async (values: LeagueFormValues) => {
      const res = await apiRequest("POST", "/api/leagues", values);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leagues"] });
      toast({
        title: "League created",
        description: "Your league has been created successfully."
      });
      setIsCreateDialogOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create league",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const form = useForm<LeagueFormValues>({
    resolver: zodResolver(leagueFormSchema),
    defaultValues: {
      name: "",
      description: "",
      startDate: null,
      endDate: null,
    }
  });

  const onSubmit = (values: LeagueFormValues) => {
    createLeagueMutation.mutate(values);
  };

  const getLeagueStatus = (league: League) => {
    const now = new Date();
    
    if (league.startDate && league.endDate) {
      const startDate = new Date(league.startDate);
      const endDate = new Date(league.endDate);
      
      if (now < startDate) {
        return { label: "Upcoming", color: "bg-blue-100 text-blue-700" };
      } else if (now > endDate) {
        return { label: "Completed", color: "bg-neutral-100 text-neutral-700" };
      } else {
        return { label: "Active", color: "bg-green-100 text-green-700" };
      }
    } else if (league.startDate) {
      const startDate = new Date(league.startDate);
      
      if (now < startDate) {
        return { label: "Upcoming", color: "bg-blue-100 text-blue-700" };
      } else {
        return { label: "Active", color: "bg-green-100 text-green-700" };
      }
    } else {
      return { label: "Draft", color: "bg-yellow-100 text-yellow-700" };
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "TBD";
    return format(new Date(dateString), "MMM d, yyyy");
  };

  const filteredLeagues = leagues
    ? leagues
        .filter(league => 
          league.name.toLowerCase().includes(searchQuery.toLowerCase())
        )
        .sort((a, b) => a.name.localeCompare(b.name))
    : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Leagues</h1>
          <p className="text-neutral-500">Create and manage leagues for your organization</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
            <Input
              placeholder="Search leagues..."
              className="pl-9 w-full sm:w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Create League
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>Create a New League</DialogTitle>
                <DialogDescription>
                  Fill out the form below to create a new league in your organization.
                </DialogDescription>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>League Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Summer Youth League 2023" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description (Optional)</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Provide a brief description of your league"
                            className="min-h-[100px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start Date (Optional)</FormLabel>
                          <FormControl>
                            <Input 
                              type="date" 
                              {...field} 
                              value={field.value || ""}
                              onChange={(e) => field.onChange(e.target.value || null)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Date (Optional)</FormLabel>
                          <FormControl>
                            <Input 
                              type="date" 
                              {...field} 
                              value={field.value || ""}
                              onChange={(e) => field.onChange(e.target.value || null)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="flex justify-end gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsCreateDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createLeagueMutation.isPending}
                    >
                      {createLeagueMutation.isPending ? "Creating..." : "Create League"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {isLoading ? (
        <LeagueListSkeleton />
      ) : filteredLeagues.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6">
            <Trophy className="h-12 w-12 text-neutral-300 mb-4" />
            <h3 className="text-lg font-medium">No leagues found</h3>
            <p className="text-neutral-500 mb-4">
              {searchQuery ? "No leagues match your search criteria" : "Create your first league to get started"}
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create League
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredLeagues.map(league => {
            const status = getLeagueStatus(league);
            
            return (
              <Card key={league.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div className="bg-primary-100 w-12 h-12 rounded-lg flex items-center justify-center text-primary-700 mb-3">
                      <Trophy className="h-6 w-6" />
                    </div>
                    <Badge className={status.color}>
                      {status.label}
                    </Badge>
                  </div>
                  <CardTitle className="line-clamp-1">{league.name}</CardTitle>
                </CardHeader>
                <CardContent className="pb-2">
                  {league.description && (
                    <p className="text-sm text-neutral-600 mb-3 line-clamp-2">
                      {league.description}
                    </p>
                  )}
                  
                  <div className="space-y-2 mt-3">
                    <div className="flex items-center text-sm text-neutral-600">
                      <Calendar className="h-4 w-4 mr-2 text-neutral-400" />
                      <span className="font-medium mr-1">Start:</span> {formatDate(league.startDate)}
                    </div>
                    <div className="flex items-center text-sm text-neutral-600">
                      <Flag className="h-4 w-4 mr-2 text-neutral-400" />
                      <span className="font-medium mr-1">End:</span> {formatDate(league.endDate)}
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    <Users className="h-4 w-4 mr-2" />
                    View Teams
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function LeagueListSkeleton() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <Card key={i}>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <Skeleton className="w-12 h-12 rounded-lg mb-3" />
              <Skeleton className="h-5 w-20" />
            </div>
            <Skeleton className="h-6 w-40" />
          </CardHeader>
          <CardContent className="pb-2">
            <Skeleton className="h-4 w-full mb-1" />
            <Skeleton className="h-4 w-4/5 mb-3" />
            
            <div className="space-y-2 mt-3">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
            </div>
          </CardContent>
          <CardFooter>
            <Skeleton className="h-9 w-full" />
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}
