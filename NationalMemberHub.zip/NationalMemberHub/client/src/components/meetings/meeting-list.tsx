import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { format, addHours, isAfter } from "date-fns";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AvatarGroup } from "@/components/ui/avatar-group";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

import {
  Calendar,
  Video,
  Users,
  Plus,
  Edit,
  Trash2,
  ExternalLink,
  Calendar as CalendarIcon,
} from "lucide-react";

interface Meeting {
  id: number;
  title: string;
  description: string;
  startTime: string;
  endTime: string;
  platform: string;
  link: string;
  hostId: number;
  clubId?: number;
  leagueId?: number;
  createdAt: string;
}

interface User {
  id: number;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  role: string;
}

const meetingFormSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().optional(),
  startTime: z.string().refine(val => {
    const date = new Date(val);
    return !isNaN(date.getTime()) && isAfter(date, new Date());
  }, "Start time must be in the future"),
  endTime: z.string().refine(val => {
    const date = new Date(val);
    return !isNaN(date.getTime());
  }, "End time must be valid"),
  platform: z.string().min(1, "Platform is required"),
  link: z.string().url("Must be a valid URL"),
  participants: z.array(z.number()).optional(),
});

type MeetingFormValues = z.infer<typeof meetingFormSchema>;

export function MeetingList() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("upcoming");
  
  const { data: meetings, isLoading } = useQuery<Meeting[]>({
    queryKey: ["/api/meetings"],
    queryFn: getQueryFn({ on401: "throw" })
  });
  
  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
    queryFn: getQueryFn({ on401: "throw" })
  });

  const createMeetingMutation = useMutation({
    mutationFn: async (values: MeetingFormValues) => {
      const res = await apiRequest("POST", "/api/meetings", values);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meetings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/meetings/upcoming"] });
      toast({
        title: "Meeting scheduled",
        description: "Your meeting has been scheduled successfully."
      });
      setIsCreateDialogOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to schedule meeting",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const deleteMeetingMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/meetings/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meetings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/meetings/upcoming"] });
      toast({
        title: "Meeting deleted",
        description: "The meeting has been deleted successfully."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete meeting",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const form = useForm<MeetingFormValues>({
    resolver: zodResolver(meetingFormSchema),
    defaultValues: {
      title: "",
      description: "",
      startTime: format(addHours(new Date(), 1), "yyyy-MM-dd'T'HH:mm"),
      endTime: format(addHours(new Date(), 2), "yyyy-MM-dd'T'HH:mm"),
      platform: "zoom",
      link: "",
      participants: [],
    }
  });

  const onSubmit = (values: MeetingFormValues) => {
    createMeetingMutation.mutate(values);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this meeting?")) {
      deleteMeetingMutation.mutate(id);
    }
  };

  const handleJoinMeeting = (link: string) => {
    window.open(link, "_blank");
  };

  const filteredMeetings = meetings ? meetings.filter(meeting => {
    const meetingDate = new Date(meeting.startTime);
    const now = new Date();
    
    if (activeTab === "upcoming") {
      return meetingDate > now;
    } else {
      return meetingDate <= now;
    }
  }).sort((a, b) => {
    return new Date(a.startTime).getTime() - new Date(b.startTime).getTime();
  }) : [];

  const formatMeetingTime = (start: string, end: string) => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return `${format(startDate, "MMM d, yyyy")} • ${format(startDate, "h:mm a")} - ${format(endDate, "h:mm a")}`;
  };

  const getPlatformColor = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'zoom':
        return 'bg-blue-100 text-blue-700';
      case 'teams':
        return 'bg-purple-100 text-purple-700';
      case 'google':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-neutral-100 text-neutral-700';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Meetings</h1>
          <p className="text-neutral-500">Schedule and manage your organization's meetings</p>
        </div>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Schedule Meeting
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Schedule a New Meeting</DialogTitle>
              <DialogDescription>
                Fill out the form below to schedule a new meeting.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Meeting Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Weekly Team Sync" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description (Optional)</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Meeting agenda and details" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Start Time</FormLabel>
                        <FormControl>
                          <Input type="datetime-local" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="endTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Time</FormLabel>
                        <FormControl>
                          <Input type="datetime-local" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="platform"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Platform</FormLabel>
                      <FormControl>
                        <select 
                          className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors focus:outline-none focus:ring-1 focus:ring-ring"
                          {...field}
                        >
                          <option value="zoom">Zoom</option>
                          <option value="teams">Microsoft Teams</option>
                          <option value="google">Google Meet</option>
                        </select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="link"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Meeting Link</FormLabel>
                      <FormControl>
                        <Input placeholder="https://..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {users && (
                  <FormField
                    control={form.control}
                    name="participants"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Participants</FormLabel>
                        <FormControl>
                          <select 
                            multiple
                            value={field.value}
                            onChange={e => {
                              const values = Array.from(e.target.selectedOptions, option => parseInt(option.value));
                              field.onChange(values);
                            }}
                            className="flex h-32 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors focus:outline-none focus:ring-1 focus:ring-ring"
                          >
                            {users.filter(u => u.id !== user?.id).map(user => (
                              <option key={user.id} value={user.id}>
                                {user.firstName} {user.lastName} ({user.email})
                              </option>
                            ))}
                          </select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
                
                <div className="flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createMeetingMutation.isPending}
                  >
                    {createMeetingMutation.isPending ? "Scheduling..." : "Schedule Meeting"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="upcoming">
            <Calendar className="h-4 w-4 mr-2" />
            Upcoming
          </TabsTrigger>
          <TabsTrigger value="past">
            <Calendar className="h-4 w-4 mr-2" />
            Past
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="upcoming" className="space-y-4">
          {isLoading ? (
            <MeetingsListSkeleton />
          ) : filteredMeetings.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center p-6">
                <CalendarIcon className="h-12 w-12 text-neutral-300 mb-4" />
                <h3 className="text-lg font-medium">No upcoming meetings</h3>
                <p className="text-neutral-500 mb-4">Schedule a new meeting to get started</p>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Schedule Meeting
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredMeetings.map(meeting => (
                <Card key={meeting.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <Badge className={getPlatformColor(meeting.platform)}>
                          {meeting.platform.charAt(0).toUpperCase() + meeting.platform.slice(1)}
                        </Badge>
                        <CardTitle className="mt-2 text-lg">{meeting.title}</CardTitle>
                      </div>
                      {meeting.hostId === user?.id && (
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-500">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-neutral-500"
                            onClick={() => handleDelete(meeting.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                    <CardDescription className="flex items-center mt-1">
                      <CalendarIcon className="h-3 w-3 mr-1" />
                      {formatMeetingTime(meeting.startTime, meeting.endTime)}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    {meeting.description && (
                      <p className="text-sm text-neutral-600 mb-3 line-clamp-2">
                        {meeting.description}
                      </p>
                    )}
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-neutral-400" />
                      <AvatarGroup users={[{ id: 1, firstName: "John", lastName: "Doe" }]} max={3} />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className="w-full mt-2" 
                      onClick={() => handleJoinMeeting(meeting.link)}
                    >
                      <Video className="h-4 w-4 mr-2" />
                      Join Meeting
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="past" className="space-y-4">
          {isLoading ? (
            <MeetingsListSkeleton />
          ) : filteredMeetings.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center p-6">
                <CalendarIcon className="h-12 w-12 text-neutral-300 mb-4" />
                <h3 className="text-lg font-medium">No past meetings</h3>
                <p className="text-neutral-500">Past meetings will appear here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredMeetings.map(meeting => (
                <Card key={meeting.id} className="opacity-75">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <Badge className={getPlatformColor(meeting.platform)}>
                          {meeting.platform.charAt(0).toUpperCase() + meeting.platform.slice(1)}
                        </Badge>
                        <CardTitle className="mt-2 text-lg">{meeting.title}</CardTitle>
                      </div>
                      {meeting.hostId === user?.id && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-neutral-500"
                          onClick={() => handleDelete(meeting.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    <CardDescription className="flex items-center mt-1">
                      <CalendarIcon className="h-3 w-3 mr-1" />
                      {formatMeetingTime(meeting.startTime, meeting.endTime)}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    {meeting.description && (
                      <p className="text-sm text-neutral-600 mb-3 line-clamp-2">
                        {meeting.description}
                      </p>
                    )}
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-neutral-400" />
                      <AvatarGroup users={[{ id: 1, firstName: "John", lastName: "Doe" }]} max={3} />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      variant="outline" 
                      className="w-full mt-2" 
                      onClick={() => handleJoinMeeting(meeting.link)}
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View Recording
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function MeetingsListSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <Card key={i}>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <Skeleton className="h-6 w-16 mb-2" />
                <Skeleton className="h-6 w-40" />
              </div>
              <Skeleton className="h-8 w-16" />
            </div>
            <Skeleton className="h-4 w-32 mt-2" />
          </CardHeader>
          <CardContent className="pb-2">
            <Skeleton className="h-4 w-full mb-3" />
            <Skeleton className="h-4 w-full mb-3" />
            <div className="flex items-center gap-2">
              <Skeleton className="h-4 w-4" />
              <div className="flex -space-x-1">
                <Skeleton className="h-6 w-6 rounded-full" />
                <Skeleton className="h-6 w-6 rounded-full" />
                <Skeleton className="h-6 w-6 rounded-full" />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Skeleton className="h-9 w-full mt-2" />
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}
