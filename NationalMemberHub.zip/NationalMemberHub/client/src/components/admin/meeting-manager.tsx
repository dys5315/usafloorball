import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Mic, MicOff, Video, VideoOff, UserPlus, MessageSquare, File, Download, Clock } from "lucide-react";

interface Meeting {
  id: number;
  title: string;
  date: string;
  time: string;
  duration: string;
  participants: string[];
  status: "upcoming" | "active" | "completed";
  summary?: string;
  notes?: string;
  recordingUrl?: string;
}

// Sample meeting data
const sampleMeetings: Meeting[] = [
  {
    id: 1,
    title: "Competition Committee Monthly Meeting",
    date: "April 5, 2025",
    time: "2:00 PM EST",
    duration: "1 hour",
    participants: ["John Smith", "Jane Doe", "Mike Johnson", "Sarah Williams"],
    status: "upcoming"
  },
  {
    id: 2,
    title: "Development Committee Weekly Update",
    date: "April 7, 2025",
    time: "3:30 PM EST",
    duration: "45 minutes",
    participants: ["Alex Rodriguez", "Emily Chen", "Tom Phillips"],
    status: "upcoming"
  },
  {
    id: 3,
    title: "National Teams Review",
    date: "March 29, 2025",
    time: "1:00 PM EST",
    duration: "1.5 hours",
    participants: ["David Peterson", "Sophia Martinez", "Robert Taylor", "Lisa Wang"],
    status: "completed",
    summary: "The committee reviewed national team selections for the upcoming international tournament. Key points discussed include final roster decisions, training camp schedule, and travel arrangements. Action items were assigned for equipment procurement and medical staff coordination.",
    notes: "• Confirmed 24-player roster for men's team\n• Scheduled training camp for May 10-17\n• Need to finalize travel arrangements by April 15\n• Equipment inventory to be completed by April 10\n• Medical staff schedule confirmed",
    recordingUrl: "#"
  }
];

export default function MeetingManager() {
  const [meetings, setMeetings] = useState<Meeting[]>(sampleMeetings);
  const [isInMeeting, setIsInMeeting] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [activeMeeting, setActiveMeeting] = useState<Meeting | null>(null);
  const [meetingNotes, setMeetingNotes] = useState("");
  const { toast } = useToast();

  const startMeeting = (meeting: Meeting) => {
    setActiveMeeting(meeting);
    setIsInMeeting(true);
    setMeetingNotes("");
    
    // In a real implementation, this would initialize the WebRTC connection
    toast({
      title: "Meeting Started",
      description: `You've joined: ${meeting.title}`,
    });
  };

  const endMeeting = () => {
    // In a real implementation, this would generate the AI summary
    // using an API like Otter.ai based on the meeting transcript
    
    const updatedMeetings = meetings.map(m => {
      if (m.id === activeMeeting?.id) {
        return {
          ...m,
          status: "completed" as const,
          summary: "AI-generated summary would appear here based on meeting transcript.",
          notes: meetingNotes || "No notes were taken during this meeting."
        };
      }
      return m;
    });
    
    setMeetings(updatedMeetings);
    setIsInMeeting(false);
    setActiveMeeting(null);
    
    toast({
      title: "Meeting Ended",
      description: "Meeting recording and AI summary are being processed.",
    });
  };

  const generateAISummary = () => {
    toast({
      title: "Generating AI Summary",
      description: "Processing audio to create a meeting summary...",
    });
    
    // In a real implementation, this would call the Otter.ai API or similar
    setTimeout(() => {
      toast({
        title: "AI Summary Ready",
        description: "The meeting summary has been generated successfully.",
      });
    }, 2000);
  };

  if (isInMeeting && activeMeeting) {
    return (
      <div className="space-y-4">
        <Card>
          <CardHeader className="bg-primary/5">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{activeMeeting.title}</CardTitle>
                <CardDescription>{activeMeeting.date} • {activeMeeting.time} • {activeMeeting.duration}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant={audioEnabled ? "default" : "outline"} 
                  size="sm" 
                  onClick={() => setAudioEnabled(!audioEnabled)}
                >
                  {audioEnabled ? <Mic className="h-4 w-4 mr-2" /> : <MicOff className="h-4 w-4 mr-2" />}
                  {audioEnabled ? "Mute" : "Unmute"}
                </Button>
                <Button 
                  variant={videoEnabled ? "default" : "outline"} 
                  size="sm"
                  onClick={() => setVideoEnabled(!videoEnabled)}
                >
                  {videoEnabled ? <Video className="h-4 w-4 mr-2" /> : <VideoOff className="h-4 w-4 mr-2" />}
                  {videoEnabled ? "Stop Video" : "Start Video"}
                </Button>
                <Button variant="destructive" size="sm" onClick={endMeeting}>
                  End Meeting
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
              <div className="col-span-2 p-4 min-h-[400px] border-r">
                <div className="bg-muted/50 rounded-lg h-[400px] flex items-center justify-center">
                  <div className="text-center">
                    <Video className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p className="text-muted-foreground">Video conference would appear here</p>
                    <p className="text-sm text-muted-foreground mt-2">Connected via WebRTC</p>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <div className="mb-4">
                  <h3 className="text-sm font-medium mb-2">Meeting Notes</h3>
                  <Textarea 
                    placeholder="Take notes during the meeting..."
                    className="h-[200px]"
                    value={meetingNotes}
                    onChange={(e) => setMeetingNotes(e.target.value)}
                  />
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-2">Participants ({activeMeeting.participants.length})</h3>
                  <div className="space-y-2 max-h-[150px] overflow-y-auto">
                    {activeMeeting.participants.map((participant, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm">
                        <div className="h-2 w-2 rounded-full bg-green-500"></div>
                        {participant}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="bg-muted/20 flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              <Clock className="h-4 w-4 inline mr-1" />
              Meeting in progress
            </p>
            <div>
              <Button variant="outline" size="sm">
                <UserPlus className="h-4 w-4 mr-2" />
                Invite
              </Button>
            </div>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Meeting Manager</h2>
        <Button>
          <MessageSquare className="mr-2 h-4 w-4" />
          Schedule New Meeting
        </Button>
      </div>

      <Tabs defaultValue="upcoming">
        <TabsList>
          <TabsTrigger value="upcoming">Upcoming Meetings</TabsTrigger>
          <TabsTrigger value="completed">Past Meetings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="upcoming" className="space-y-4 mt-4">
          {meetings.filter(m => m.status === "upcoming").map((meeting) => (
            <Card key={meeting.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{meeting.title}</CardTitle>
                    <CardDescription>{meeting.date} • {meeting.time} • {meeting.duration}</CardDescription>
                  </div>
                  <Button onClick={() => startMeeting(meeting)}>Join Meeting</Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <UserPlus className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    {meeting.participants.length} Participants
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
          
          {meetings.filter(m => m.status === "upcoming").length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No upcoming meetings scheduled</p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="completed" className="space-y-6 mt-4">
          {meetings.filter(m => m.status === "completed").map((meeting) => (
            <Card key={meeting.id} className="overflow-hidden">
              <CardHeader>
                <CardTitle>{meeting.title}</CardTitle>
                <CardDescription>{meeting.date} • {meeting.time} • {meeting.duration}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">AI Meeting Summary</h3>
                  <div className="bg-muted/30 rounded-md p-3 text-sm">
                    {meeting.summary || "No AI summary available."}
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-sm font-medium mb-2">Meeting Notes</h3>
                  <div className="bg-muted/30 rounded-md p-3 text-sm whitespace-pre-line">
                    {meeting.notes || "No notes were taken during this meeting."}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-muted/20 flex justify-between">
                <div className="flex items-center gap-4">
                  <Button variant="outline" size="sm">
                    <File className="h-4 w-4 mr-2" />
                    View Transcript
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download Recording
                  </Button>
                </div>
                <Button variant="outline" size="sm" onClick={generateAISummary}>
                  Regenerate AI Summary
                </Button>
              </CardFooter>
            </Card>
          ))}
          
          {meetings.filter(m => m.status === "completed").length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No past meetings found</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}