import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

type CommitteeNode = {
  id: string;
  name: string;
  description: string;
  color: string;
};

type CommitteeConnection = {
  source: string;
  target: string;
  description: string;
};

// Committee data with color assignments
const committees: CommitteeNode[] = [
  { 
    id: 'central', 
    name: 'USA Floorball', 
    description: 'National governing body coordinating all committees',
    color: '#3b82f6' // blue-500
  },
  { 
    id: 'competition', 
    name: 'Competition Committee', 
    description: 'Oversees tournament organization, rules, and league structure',
    color: '#ef4444' // red-500
  },
  { 
    id: 'development', 
    name: 'Development Committee', 
    description: 'Focuses on growing the sport through training programs and outreach',
    color: '#10b981' // emerald-500
  },
  { 
    id: 'finance', 
    name: 'Finance Committee', 
    description: 'Manages budgeting, financial planning, and resource allocation',
    color: '#6366f1' // indigo-500
  },
  { 
    id: 'governance', 
    name: 'Governance Committee',
    description: 'Ensures adherence to bylaws, policies, and legal requirements',
    color: '#8b5cf6' // violet-500
  },
  { 
    id: 'marcom', 
    name: 'Marcom Committee', 
    description: 'Handles marketing, communications, and brand development',
    color: '#f59e0b' // amber-500
  },
  { 
    id: 'membership', 
    name: 'Membership Committee', 
    description: 'Manages member relations and growth strategies',
    color: '#14b8a6' // teal-500
  },
  { 
    id: 'national-teams', 
    name: 'National Teams Committee',
    description: 'Coordinates selection, training, and management of national teams',
    color: '#ec4899' // pink-500
  },
  { 
    id: 'special-olympics', 
    name: 'Special Olympics Committee', 
    description: 'Drives inclusive programs for athletes with intellectual disabilities',
    color: '#06b6d4' // cyan-500
  },
];

// Key committee relationships
const connections: CommitteeConnection[] = [
  { source: 'central', target: 'competition', description: 'Tournament organization and oversight' },
  { source: 'central', target: 'development', description: 'Training program coordination' },
  { source: 'central', target: 'finance', description: 'Budget allocation and approval' },
  { source: 'central', target: 'governance', description: 'Policy implementation' },
  { source: 'central', target: 'marcom', description: 'Brand strategy direction' },
  { source: 'central', target: 'membership', description: 'Membership growth targets' },
  { source: 'central', target: 'national-teams', description: 'International representation' },
  { source: 'central', target: 'special-olympics', description: 'Inclusion initiative oversight' },
  { source: 'competition', target: 'national-teams', description: 'Selection criteria and tournament scheduling' },
  { source: 'development', target: 'membership', description: 'Player development pathways' },
  { source: 'marcom', target: 'membership', description: 'Member communication strategies' },
  { source: 'finance', target: 'national-teams', description: 'Travel and equipment funding' },
  { source: 'governance', target: 'competition', description: 'Rules enforcement and compliance' },
  { source: 'development', target: 'special-olympics', description: 'Inclusive coaching development' },
  { source: 'marcom', target: 'competition', description: 'Tournament promotion' },
  { source: 'finance', target: 'development', description: 'Training program funding' },
];

export default function CommitteeNetwork() {
  const [selectedCommittee, setSelectedCommittee] = useState<CommitteeNode | null>(null);
  const [selectedConnection, setSelectedConnection] = useState<CommitteeConnection | null>(null);
  const { toast } = useToast();

  const handleCommitteeClick = (committee: CommitteeNode) => {
    setSelectedCommittee(committee);
    setSelectedConnection(null);
    toast({
      title: committee.name,
      description: committee.description,
      duration: 3000,
    });
  };

  const handleConnectionClick = (connection: CommitteeConnection) => {
    setSelectedConnection(connection);
    setSelectedCommittee(null);
    const source = committees.find(c => c.id === connection.source);
    const target = committees.find(c => c.id === connection.target);
    if (source && target) {
      toast({
        title: `${source.name} → ${target.name}`,
        description: connection.description,
        duration: 3000,
      });
    }
  };

  // Get related committees for selected committee
  const getRelatedCommittees = (committeeId: string) => {
    return connections
      .filter(conn => conn.source === committeeId || conn.target === committeeId)
      .map(conn => conn.source === committeeId ? conn.target : conn.source);
  };

  return (
    <div className="relative h-[500px] bg-background rounded-md border p-4 overflow-hidden">
      {/* Central committee */}
      <div 
        className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full flex items-center justify-center cursor-pointer z-10 border-2 ${selectedCommittee?.id === 'central' ? 'ring-4 ring-primary ring-opacity-50' : ''}`}
        style={{ backgroundColor: committees.find(c => c.id === 'central')?.color }}
        onClick={() => handleCommitteeClick(committees.find(c => c.id === 'central')!)}
      >
        <span className="text-white font-semibold text-xs text-center">USA Floorball</span>
      </div>

      {/* Other committees positioned in a circle */}
      {committees.filter(c => c.id !== 'central').map((committee, index) => {
        const angle = (index * (2 * Math.PI / 8));
        const radius = 180;
        const left = `calc(50% + ${radius * Math.cos(angle)}px)`;
        const top = `calc(50% + ${radius * Math.sin(angle)}px)`;
        const isHighlighted = selectedCommittee?.id === committee.id || 
                             (selectedCommittee && getRelatedCommittees(selectedCommittee.id).includes(committee.id)) ||
                             (selectedConnection && (selectedConnection.source === committee.id || selectedConnection.target === committee.id));
        
        return (
          <div 
            key={committee.id}
            className={`absolute w-20 h-20 transform -translate-x-1/2 -translate-y-1/2 rounded-full flex items-center justify-center cursor-pointer z-10 border-2 transition-all duration-300 ${isHighlighted ? 'ring-4 ring-primary ring-opacity-50 scale-110' : 'opacity-80 scale-100'}`}
            style={{ 
              left, 
              top,
              backgroundColor: committee.color
            }}
            onClick={() => handleCommitteeClick(committee)}
          >
            <span className="text-white font-semibold text-xs text-center px-1">{committee.name.replace(' Committee', '')}</span>
          </div>
        );
      })}

      {/* Connection lines */}
      <svg className="absolute top-0 left-0 w-full h-full z-0">
        {connections.map((connection, index) => {
          const source = committees.find(c => c.id === connection.source);
          const target = committees.find(c => c.id === connection.target);
          
          if (!source || !target) return null;
          
          // Calculate positions for central node
          let sourceX = '50%';
          let sourceY = '50%';
          
          // Calculate positions for other nodes
          if (source.id !== 'central') {
            const sourceIndex = committees.findIndex(c => c.id === source.id) - 1; // -1 because central is first
            const sourceAngle = (sourceIndex * (2 * Math.PI / 8));
            const sourceRadius = 180;
            sourceX = `calc(50% + ${sourceRadius * Math.cos(sourceAngle)}px)`;
            sourceY = `calc(50% + ${sourceRadius * Math.sin(sourceAngle)}px)`;
          }
          
          let targetX = '50%';
          let targetY = '50%';
          
          if (target.id !== 'central') {
            const targetIndex = committees.findIndex(c => c.id === target.id) - 1; // -1 because central is first
            const targetAngle = (targetIndex * (2 * Math.PI / 8));
            const targetRadius = 180;
            targetX = `calc(50% + ${targetRadius * Math.cos(targetAngle)}px)`;
            targetY = `calc(50% + ${targetRadius * Math.sin(targetAngle)}px)`;
          }
          
          const isHighlighted = 
            (selectedCommittee && (selectedCommittee.id === source.id || selectedCommittee.id === target.id)) ||
            selectedConnection === connection;
          
          return (
            <line
              key={`${source.id}-${target.id}-${index}`}
              x1={sourceX}
              y1={sourceY}
              x2={targetX}
              y2={targetY}
              stroke={isHighlighted ? source.color : '#e2e8f0'}
              strokeWidth={isHighlighted ? 3 : 1.5}
              strokeOpacity={isHighlighted ? 0.8 : 0.4}
              className="cursor-pointer transition-all duration-300"
              onClick={() => handleConnectionClick(connection)}
            />
          );
        })}
      </svg>

      {/* Info panel for selected item */}
      {(selectedCommittee || selectedConnection) && (
        <div className="absolute bottom-4 left-4 right-4 bg-background/90 p-3 rounded-md border shadow-md">
          {selectedCommittee && (
            <>
              <h4 className="font-semibold" style={{ color: selectedCommittee.color }}>{selectedCommittee.name}</h4>
              <p className="text-sm text-muted-foreground">{selectedCommittee.description}</p>
            </>
          )}
          {selectedConnection && (
            <>
              <h4 className="font-semibold text-primary">
                {committees.find(c => c.id === selectedConnection.source)?.name} → {committees.find(c => c.id === selectedConnection.target)?.name}
              </h4>
              <p className="text-sm text-muted-foreground">{selectedConnection.description}</p>
            </>
          )}
        </div>
      )}
    </div>
  );
}