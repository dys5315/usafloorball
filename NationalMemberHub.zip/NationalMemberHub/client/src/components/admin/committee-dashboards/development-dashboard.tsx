import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GraduationCap, Users, Map, FileText, MessageSquare } from "lucide-react";

export default function DevelopmentDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Development Committee</h2>
          <p className="text-muted-foreground">Growing the sport through training programs and outreach</p>
        </div>
        <Button>
          <MessageSquare className="mr-2 h-4 w-4" />
          Committee Chat
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Training Programs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
          </CardContent>
          <CardFooter>
            <GraduationCap className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Active nationwide</span>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Certified Coaches</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">147</div>
          </CardContent>
          <CardFooter>
            <Users className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">+15 since last month</span>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Outreach Regions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">23</div>
          </CardContent>
          <CardFooter>
            <Map className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Active development areas</span>
          </CardFooter>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Coach Education Program</CardTitle>
            <CardDescription>Upcoming certification courses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-4 border-b">
                <div>
                  <h4 className="font-semibold">Level 1 Certification</h4>
                  <div className="text-sm text-muted-foreground">Virtual Training</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">Apr 10-12, 2025</div>
                </div>
              </div>
              <div className="flex items-center justify-between pb-4 border-b">
                <div>
                  <h4 className="font-semibold">Level 2 Certification</h4>
                  <div className="text-sm text-muted-foreground">Chicago, IL</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">Apr 18-20, 2025</div>
                </div>
              </div>
              <div className="flex items-center justify-between pb-4 border-b">
                <div>
                  <h4 className="font-semibold">Youth Development Workshop</h4>
                  <div className="text-sm text-muted-foreground">Denver, CO</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">May 5-6, 2025</div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold">Advanced Tactical Course</h4>
                  <div className="text-sm text-muted-foreground">Minneapolis, MN</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">May 12-14, 2025</div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm">Program Management</Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Development Resources</CardTitle>
            <CardDescription>Recently added training materials</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4 pb-4 border-b">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Youth Practice Plan Templates</p>
                  <p className="text-xs text-muted-foreground">Age-appropriate drills and exercises</p>
                  <p className="text-xs text-muted-foreground mt-1">Added March 28, 2025</p>
                </div>
              </div>
              <div className="flex items-start gap-4 pb-4 border-b">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Coaching Manual - 2025 Edition</p>
                  <p className="text-xs text-muted-foreground">Updated with latest techniques</p>
                  <p className="text-xs text-muted-foreground mt-1">Added March 22, 2025</p>
                </div>
              </div>
              <div className="flex items-start gap-4 pb-4 border-b">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">School Program Curriculum</p>
                  <p className="text-xs text-muted-foreground">PE teacher resource package</p>
                  <p className="text-xs text-muted-foreground mt-1">Added March 15, 2025</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Player Development Pathway</p>
                  <p className="text-xs text-muted-foreground">Long-term athlete development guide</p>
                  <p className="text-xs text-muted-foreground mt-1">Added March 10, 2025</p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm">Resource Library</Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}