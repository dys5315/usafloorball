import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trophy, Calendar, Users, FileText, MessageSquare } from "lucide-react";

export default function CompetitionDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Competition Committee</h2>
          <p className="text-muted-foreground">Overseeing tournament organization, rules, and league structure</p>
        </div>
        <Button>
          <MessageSquare className="mr-2 h-4 w-4" />
          Committee Chat
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Tournaments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4</div>
          </CardContent>
          <CardFooter>
            <Trophy className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Across 3 regions</span>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">7</div>
          </CardContent>
          <CardFooter>
            <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Next 30 days</span>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Registered Teams</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">56</div>
          </CardContent>
          <CardFooter>
            <Users className="h-4 w-4 mr-1 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Active in competitions</span>
          </CardFooter>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Tournament Schedule</CardTitle>
            <CardDescription>Upcoming competitions and events</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-4 border-b">
                <div>
                  <h4 className="font-semibold">Regional Qualifier - West</h4>
                  <div className="text-sm text-muted-foreground">Portland, OR</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">Apr 15-17, 2025</div>
                </div>
              </div>
              <div className="flex items-center justify-between pb-4 border-b">
                <div>
                  <h4 className="font-semibold">Regional Qualifier - East</h4>
                  <div className="text-sm text-muted-foreground">Boston, MA</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">Apr 22-24, 2025</div>
                </div>
              </div>
              <div className="flex items-center justify-between pb-4 border-b">
                <div>
                  <h4 className="font-semibold">Regional Qualifier - South</h4>
                  <div className="text-sm text-muted-foreground">Austin, TX</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">May 6-8, 2025</div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold">National Championship</h4>
                  <div className="text-sm text-muted-foreground">Chicago, IL</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">June 15-20, 2025</div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm">Manage Schedule</Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Rule Changes</CardTitle>
            <CardDescription>Updated competition guidelines</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4 pb-4 border-b">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Updated Match Duration</p>
                  <p className="text-xs text-muted-foreground">Championship matches now use 20-minute periods</p>
                  <p className="text-xs text-muted-foreground mt-1">Updated March 25, 2025</p>
                </div>
              </div>
              <div className="flex items-start gap-4 pb-4 border-b">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Roster Size Increase</p>
                  <p className="text-xs text-muted-foreground">Teams can register up to 22 players per tournament</p>
                  <p className="text-xs text-muted-foreground mt-1">Updated March 18, 2025</p>
                </div>
              </div>
              <div className="flex items-start gap-4 pb-4 border-b">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Face-off Positioning</p>
                  <p className="text-xs text-muted-foreground">New positioning guidelines for face-offs</p>
                  <p className="text-xs text-muted-foreground mt-1">Updated March 10, 2025</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Timeout Allowance</p>
                  <p className="text-xs text-muted-foreground">Additional timeout in overtime periods</p>
                  <p className="text-xs text-muted-foreground mt-1">Updated March 5, 2025</p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm">Rule Management</Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}