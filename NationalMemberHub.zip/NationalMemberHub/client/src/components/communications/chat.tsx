import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { useWebSocket } from "@/lib/websocket";
import { useAuth } from "@/hooks/use-auth";
import { format } from "date-fns";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { 
  Send, 
  Users, 
  Building,
  Trophy,
  MessageSquare,
  RefreshCw,
} from "lucide-react";

interface Message {
  id: number;
  content: string;
  senderId: number;
  channelId: string;
  sentAt: string;
  sender?: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

interface Channel {
  id: string;
  name: string;
  type: 'general' | 'club' | 'league';
  entityId?: number;
}

const messageSchema = z.object({
  content: z.string().min(1, "Message cannot be empty"),
});

type MessageFormValues = z.infer<typeof messageSchema>;

export function Chat() {
  const { user } = useAuth();
  const { isConnected, messages: wsMessages, sendMessage } = useWebSocket();
  const [activeChannel, setActiveChannel] = useState<Channel>({ id: 'general', name: 'General', type: 'general' });
  const messageEndRef = useRef<HTMLDivElement>(null);
  
  // In a real app, you'd fetch channels from the backend
  const channels: Channel[] = [
    { id: 'general', name: 'General', type: 'general' },
    { id: 'announcements', name: 'Announcements', type: 'general' },
    { id: 'club-1', name: 'Downtown Sports Club', type: 'club', entityId: 1 },
    { id: 'club-2', name: 'Westside Athletics', type: 'club', entityId: 2 },
    { id: 'league-1', name: 'Summer Youth League', type: 'league', entityId: 1 },
  ];
  
  const { data: channelMessages, isLoading } = useQuery<Message[]>({
    queryKey: [`/api/messages/${activeChannel.id}`],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const form = useForm<MessageFormValues>({
    resolver: zodResolver(messageSchema),
    defaultValues: {
      content: "",
    }
  });

  const onSubmit = (values: MessageFormValues) => {
    if (!user) return;
    
    sendMessage({
      type: 'chat',
      content: values.content,
      senderId: user.id,
      channelId: activeChannel.id
    });
    
    form.reset();
  };

  // Scroll to bottom when messages change
  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [channelMessages, wsMessages]);

  // Combine backend-fetched messages with websocket messages
  const allMessages = [...(channelMessages || [])];
  
  // Add any websocket messages for this channel
  wsMessages.forEach(wsMsg => {
    if (wsMsg.type === 'chat' && wsMsg.message.channelId === activeChannel.id) {
      // Check if message already exists in allMessages
      const exists = allMessages.some(msg => msg.id === wsMsg.message.id);
      if (!exists) {
        allMessages.push(wsMsg.message);
      }
    }
  });
  
  // Sort messages by sent time
  allMessages.sort((a, b) => new Date(a.sentAt).getTime() - new Date(b.sentAt).getTime());

  const getChannelIcon = (type: string) => {
    switch (type) {
      case 'club':
        return <Building className="h-4 w-4" />;
      case 'league':
        return <Trophy className="h-4 w-4" />;
      default:
        return <MessageSquare className="h-4 w-4" />;
    }
  };

  const formatMessageTime = (timestamp: string) => {
    return format(new Date(timestamp), "h:mm a");
  };

  const getUserInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`;
  };

  const getRandomColor = (userId: number) => {
    const colors = [
      "bg-red-200 text-red-700",
      "bg-blue-200 text-blue-700",
      "bg-green-200 text-green-700",
      "bg-yellow-200 text-yellow-700",
      "bg-purple-200 text-purple-700",
      "bg-pink-200 text-pink-700",
      "bg-indigo-200 text-indigo-700",
    ];
    return colors[userId % colors.length];
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 h-[calc(100vh-180px)]">
      {/* Channel Sidebar */}
      <div className="md:col-span-1">
        <Card className="h-full">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center justify-between text-lg">
              <span>Channels</span>
              <span className={`h-2 w-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-2">
            <div className="space-y-1">
              {channels.map(channel => (
                <Button
                  key={channel.id}
                  variant={activeChannel.id === channel.id ? "secondary" : "ghost"}
                  className="w-full justify-start text-sm h-auto py-2"
                  onClick={() => setActiveChannel(channel)}
                >
                  <div className="flex items-center">
                    {getChannelIcon(channel.type)}
                    <span className="ml-2">{channel.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Chat Area */}
      <div className="md:col-span-3">
        <Card className="flex flex-col h-full">
          <CardHeader className="pb-2 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                {getChannelIcon(activeChannel.type)}
                <CardTitle className="ml-2 text-lg">{activeChannel.name}</CardTitle>
              </div>
              <div className="flex items-center gap-1 text-xs text-neutral-500">
                <Users className="h-3.5 w-3.5" />
                <span>12 members</span>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="flex-grow overflow-y-auto p-4">
            {isLoading ? (
              <ChatMessagesSkeleton />
            ) : allMessages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <MessageSquare className="h-12 w-12 text-neutral-300 mb-4" />
                <h3 className="text-lg font-medium">No messages yet</h3>
                <p className="text-neutral-500 mb-4">Be the first to send a message</p>
              </div>
            ) : (
              <div className="space-y-4">
                {allMessages.map((message) => (
                  <div key={message.id} className="flex items-start gap-3">
                    <Avatar className={`h-8 w-8 ${getRandomColor(message.senderId)}`}>
                      <AvatarFallback className="text-sm">
                        {message.sender ? 
                          getUserInitials(message.sender.firstName, message.sender.lastName) : 
                          'U'
                        }
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">
                          {message.sender ? 
                            `${message.sender.firstName} ${message.sender.lastName}` : 
                            'Unknown User'
                          }
                        </span>
                        <span className="text-xs text-neutral-500">
                          {formatMessageTime(message.sentAt)}
                        </span>
                      </div>
                      <p className="text-neutral-700">{message.content}</p>
                    </div>
                  </div>
                ))}
                <div ref={messageEndRef} />
              </div>
            )}
          </CardContent>
          
          <div className="p-4 border-t">
            {!isConnected ? (
              <div className="bg-amber-50 p-2 rounded border border-amber-200 flex items-center justify-between mb-2">
                <span className="text-amber-700 text-sm">Connection lost. Messages won't be sent.</span>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-7 gap-1" 
                  onClick={() => window.location.reload()}
                >
                  <RefreshCw className="h-3 w-3" />
                  Reconnect
                </Button>
              </div>
            ) : null}
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="flex gap-2">
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormControl>
                        <Textarea 
                          placeholder={`Message ${activeChannel.name}...`} 
                          className="min-h-[60px] resize-none"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                              e.preventDefault();
                              form.handleSubmit(onSubmit)();
                            }
                          }}
                          {...field} 
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  className="self-end"
                  disabled={!isConnected || form.formState.isSubmitting}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </Form>
          </div>
        </Card>
      </div>
    </div>
  );
}

function ChatMessagesSkeleton() {
  return (
    <div className="space-y-4">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-start gap-3">
          <Skeleton className="h-8 w-8 rounded-full" />
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-3 w-10" />
            </div>
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3 mt-1" />
          </div>
        </div>
      ))}
    </div>
  );
}
