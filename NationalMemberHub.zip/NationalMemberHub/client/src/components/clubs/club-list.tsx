import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import {
  Building,
  Users,
  Plus,
  Shield,
  Mountain,
  Waves,
  Search,
  UserPlus,
} from "lucide-react";

interface Club {
  id: number;
  name: string;
  description: string;
  createdById: number;
  createdAt: string;
  memberCount?: number;
}

const clubFormSchema = z.object({
  name: z.string().min(3, "Club name must be at least 3 characters"),
  description: z.string().optional(),
});

type ClubFormValues = z.infer<typeof clubFormSchema>;

export function ClubList() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  
  const { data: allClubs, isLoading: isLoadingAllClubs } = useQuery<Club[]>({
    queryKey: ["/api/clubs"],
    queryFn: getQueryFn({ on401: "throw" })
  });
  
  const { data: userClubs, isLoading: isLoadingUserClubs } = useQuery<Club[]>({
    queryKey: ["/api/user/clubs"],
    queryFn: getQueryFn({ on401: "throw" })
  });

  const createClubMutation = useMutation({
    mutationFn: async (values: ClubFormValues) => {
      const res = await apiRequest("POST", "/api/clubs", values);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/clubs"] });
      toast({
        title: "Club created",
        description: "Your club has been created successfully."
      });
      setIsCreateDialogOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create club",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const joinClubMutation = useMutation({
    mutationFn: async (clubId: number) => {
      if (!user) throw new Error("User not authenticated");
      const res = await apiRequest("POST", `/api/clubs/${clubId}/members`, { userId: user.id });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/clubs"] });
      toast({
        title: "Club joined",
        description: "You have successfully joined the club."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to join club",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const form = useForm<ClubFormValues>({
    resolver: zodResolver(clubFormSchema),
    defaultValues: {
      name: "",
      description: "",
    }
  });

  const onSubmit = (values: ClubFormValues) => {
    createClubMutation.mutate(values);
  };

  const handleJoinClub = (clubId: number) => {
    joinClubMutation.mutate(clubId);
  };

  const isUserInClub = (clubId: number) => {
    return userClubs?.some(club => club.id === clubId) || false;
  };

  const getClubIcon = (clubId: number) => {
    const icons = [
      <Shield key="shield" className="h-6 w-6" />,
      <Mountain key="mountain" className="h-6 w-6" />,
      <Waves key="waves" className="h-6 w-6" />,
      <Building key="building" className="h-6 w-6" />
    ];
    
    return icons[clubId % icons.length];
  };

  const getClubColor = (clubId: number) => {
    const colors = [
      "bg-primary-100 text-primary-700",
      "bg-green-100 text-green-700",
      "bg-blue-100 text-blue-700",
      "bg-purple-100 text-purple-700"
    ];
    
    return colors[clubId % colors.length];
  };

  const filteredClubs = (activeTab === "all" ? allClubs : userClubs) || [];
  
  const displayedClubs = filteredClubs
    .filter(club => club.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => a.name.localeCompare(b.name));

  const isLoading = isLoadingAllClubs || isLoadingUserClubs;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Clubs</h1>
          <p className="text-neutral-500">Explore and manage clubs in your organization</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-400" />
            <Input
              placeholder="Search clubs..."
              className="pl-9 w-full sm:w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Create Club
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>Create a New Club</DialogTitle>
                <DialogDescription>
                  Fill out the form below to create a new club in your organization.
                </DialogDescription>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Club Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Downtown Sports Club" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description (Optional)</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Provide a brief description of your club"
                            className="min-h-[100px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsCreateDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createClubMutation.isPending}
                    >
                      {createClubMutation.isPending ? "Creating..." : "Create Club"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Clubs</TabsTrigger>
          <TabsTrigger value="my">My Clubs</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="space-y-4">
          {isLoading ? (
            <ClubListSkeleton />
          ) : displayedClubs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center p-6">
                <Building className="h-12 w-12 text-neutral-300 mb-4" />
                <h3 className="text-lg font-medium">No clubs found</h3>
                <p className="text-neutral-500 mb-4">
                  {searchQuery ? "No clubs match your search criteria" : "Be the first to create a club"}
                </p>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Club
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {displayedClubs.map(club => (
                <Card key={club.id}>
                  <CardHeader className="pb-2">
                    <div className={`${getClubColor(club.id)} w-14 h-14 rounded-lg flex items-center justify-center mb-3`}>
                      {getClubIcon(club.id)}
                    </div>
                    <CardTitle>{club.name}</CardTitle>
                    <CardDescription className="flex items-center mt-1">
                      <Users className="h-3 w-3 mr-1" />
                      {club.memberCount || 0} members
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    {club.description && (
                      <p className="text-sm text-neutral-600 line-clamp-2">
                        {club.description}
                      </p>
                    )}
                  </CardContent>
                  <CardFooter>
                    {isUserInClub(club.id) ? (
                      <Button variant="outline" className="w-full">
                        <Shield className="h-4 w-4 mr-2" />
                        View Club
                      </Button>
                    ) : (
                      <Button 
                        className="w-full"
                        onClick={() => handleJoinClub(club.id)}
                        disabled={joinClubMutation.isPending}
                      >
                        <UserPlus className="h-4 w-4 mr-2" />
                        Join Club
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="my" className="space-y-4">
          {isLoading ? (
            <ClubListSkeleton />
          ) : displayedClubs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center p-6">
                <Building className="h-12 w-12 text-neutral-300 mb-4" />
                <h3 className="text-lg font-medium">You haven't joined any clubs yet</h3>
                <p className="text-neutral-500 mb-4">Join existing clubs or create your own</p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <Button variant="outline" onClick={() => setActiveTab("all")}>
                    Explore Clubs
                  </Button>
                  <Button onClick={() => setIsCreateDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Club
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {displayedClubs.map(club => (
                <Card key={club.id}>
                  <CardHeader className="pb-2">
                    <div className={`${getClubColor(club.id)} w-14 h-14 rounded-lg flex items-center justify-center mb-3`}>
                      {getClubIcon(club.id)}
                    </div>
                    <CardTitle>{club.name}</CardTitle>
                    <CardDescription className="flex items-center mt-1">
                      <Users className="h-3 w-3 mr-1" />
                      {club.memberCount || 0} members
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    {club.description && (
                      <p className="text-sm text-neutral-600 line-clamp-2">
                        {club.description}
                      </p>
                    )}
                    {club.createdById === user?.id && (
                      <Badge variant="outline" className="mt-2">
                        Admin
                      </Badge>
                    )}
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      <Shield className="h-4 w-4 mr-2" />
                      View Club
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ClubListSkeleton() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <Card key={i}>
          <CardHeader className="pb-2">
            <Skeleton className="w-14 h-14 rounded-lg mb-3" />
            <Skeleton className="h-6 w-40 mb-1" />
            <Skeleton className="h-4 w-24" />
          </CardHeader>
          <CardContent className="pb-2">
            <Skeleton className="h-4 w-full mb-1" />
            <Skeleton className="h-4 w-4/5" />
          </CardContent>
          <CardFooter>
            <Skeleton className="h-9 w-full" />
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}
