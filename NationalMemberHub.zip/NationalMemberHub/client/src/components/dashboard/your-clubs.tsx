import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Building, Mountain, Waves, Shield, ChevronRight } from "lucide-react";
import { useLocation } from "wouter";

interface Club {
  id: number;
  name: string;
  description: string;
  createdById: number;
  createdAt: string;
  memberCount?: number;
}

export function YourClubs() {
  const [, setLocation] = useLocation();
  
  const { data: clubs, isLoading } = useQuery<Club[]>({
    queryKey: ["/api/user/clubs"],
    queryFn: getQueryFn({ on401: "throw" })
  });

  // Get member count for each club
  const clubsWithMemberCount = useQuery<(Club & { memberCount: number })[]>({
    queryKey: ["/api/clubs/with-member-count"],
    queryFn: async () => {
      if (!clubs || clubs.length === 0) return [];
      
      return await Promise.all(
        clubs.map(async (club) => {
          try {
            const membersRes = await fetch(`/api/clubs/${club.id}/members`, {
              credentials: "include"
            });
            
            if (membersRes.ok) {
              const members = await membersRes.json();
              return {
                ...club,
                memberCount: members.length
              };
            }
            return { ...club, memberCount: 0 };
          } catch (error) {
            return { ...club, memberCount: 0 };
          }
        })
      );
    },
    enabled: !!clubs && clubs.length > 0
  });

  const getClubIcon = (clubId: number) => {
    const icons = [
      <Shield key="shield" className="h-6 w-6" />,
      <Mountain key="mountain" className="h-6 w-6" />,
      <Waves key="waves" className="h-6 w-6" />,
      <Building key="building" className="h-6 w-6" />
    ];
    
    return icons[clubId % icons.length];
  };

  const getClubColor = (clubId: number) => {
    const colors = [
      "bg-primary-100 text-primary-700",
      "bg-green-100 text-green-700",
      "bg-blue-100 text-blue-700",
      "bg-purple-100 text-purple-700"
    ];
    
    return colors[clubId % colors.length];
  };

  const handleClubClick = (clubId: number) => {
    setLocation(`/clubs/${clubId}`);
  };

  const isLoadingFinal = isLoading || clubsWithMemberCount.isLoading;
  const clubsData = clubsWithMemberCount.data || [];

  return (
    <Card className="h-full">
      <CardHeader className="px-6 py-4 border-b border-neutral-200 flex flex-row items-center justify-between">
        <CardTitle className="text-lg">Your Clubs</CardTitle>
        <Button 
          variant="link" 
          className="text-sm text-primary hover:text-primary-600"
          onClick={() => setLocation("/clubs")}
        >
          View all
        </Button>
      </CardHeader>
      <CardContent className="p-6">
        {isLoadingFinal ? (
          <ClubSkeleton />
        ) : clubsData.length === 0 ? (
          <div className="text-center py-4 text-neutral-500">
            <p>You are not a member of any clubs</p>
            <Button 
              variant="outline" 
              className="mt-2"
              onClick={() => setLocation("/clubs")}
            >
              Browse clubs
            </Button>
          </div>
        ) : (
          <ul className="space-y-4">
            {clubsData.map((club) => (
              <li 
                key={club.id} 
                className="flex items-center justify-between hover:bg-neutral-50 p-2 rounded-lg transition-colors cursor-pointer"
                onClick={() => handleClubClick(club.id)}
              >
                <div className="flex items-center">
                  <div className={`w-12 h-12 ${getClubColor(club.id)} rounded-lg flex items-center justify-center`}>
                    {getClubIcon(club.id)}
                  </div>
                  <div className="ml-4">
                    <h3 className="font-medium text-neutral-800">{club.name}</h3>
                    <p className="text-sm text-neutral-500">{club.memberCount} members</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="text-neutral-400 hover:text-neutral-600">
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function ClubSkeleton() {
  return (
    <ul className="space-y-4">
      {[1, 2, 3].map((i) => (
        <li key={i} className="flex items-center justify-between p-2">
          <div className="flex items-center">
            <Skeleton className="w-12 h-12 rounded-lg" />
            <div className="ml-4">
              <Skeleton className="h-5 w-40 mb-1" />
              <Skeleton className="h-4 w-24" />
            </div>
          </div>
          <Skeleton className="h-8 w-8 rounded-full" />
        </li>
      ))}
    </ul>
  );
}
