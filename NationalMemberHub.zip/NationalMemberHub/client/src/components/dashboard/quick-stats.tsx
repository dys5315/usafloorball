import { useQuery } from "@tanstack/react-query";
import { 
  Users, 
  Building, 
  Trophy, 
  FileText, 
  MessageSquare, 
  Video 
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { getQueryFn } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";

export function QuickStats() {
  const { data: clubs, isLoading: isLoadingClubs } = useQuery({
    queryKey: ["/api/clubs"],
    queryFn: getQueryFn({ on401: "throw" })
  });
  
  const { data: leagues, isLoading: isLoadingLeagues } = useQuery({
    queryKey: ["/api/leagues"],
    queryFn: getQueryFn({ on401: "throw" })
  });
  
  const { data: documents, isLoading: isLoadingDocuments } = useQuery({
    queryKey: ["/api/documents"],
    queryFn: getQueryFn({ on401: "throw" })
  });

  // Placeholder data for stats that we don't have APIs for yet
  const stats = {
    members: 248,
    clubs: clubs?.length || 0,
    leagues: leagues?.length || 0,
    documents: documents?.length || 0,
    messages: 124,
    meetings: 15
  };

  const isLoading = isLoadingClubs || isLoadingLeagues || isLoadingDocuments;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6 mb-8">
      <StatCard 
        icon={<Users className="h-5 w-5" />} 
        title="Members" 
        value={stats.members} 
        color="bg-primary-100 text-primary-500" 
        isLoading={isLoading} 
      />
      
      <StatCard 
        icon={<Building className="h-5 w-5" />} 
        title="Clubs" 
        value={stats.clubs} 
        color="bg-purple-100 text-purple-500" 
        isLoading={isLoading} 
      />
      
      <StatCard 
        icon={<Trophy className="h-5 w-5" />} 
        title="Leagues" 
        value={stats.leagues} 
        color="bg-green-100 text-green-500" 
        isLoading={isLoading} 
      />
      
      <StatCard 
        icon={<FileText className="h-5 w-5" />} 
        title="Documents" 
        value={stats.documents} 
        color="bg-yellow-100 text-yellow-500" 
        isLoading={isLoading} 
      />
      
      <StatCard 
        icon={<MessageSquare className="h-5 w-5" />} 
        title="Messages" 
        value={stats.messages} 
        color="bg-blue-100 text-blue-500" 
        isLoading={isLoading} 
      />
      
      <StatCard 
        icon={<Video className="h-5 w-5" />} 
        title="Meetings" 
        value={stats.meetings} 
        color="bg-red-100 text-red-500" 
        isLoading={isLoading} 
      />
    </div>
  );
}

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: number;
  color: string;
  isLoading: boolean;
}

function StatCard({ icon, title, value, color, isLoading }: StatCardProps) {
  return (
    <Card>
      <CardContent className="p-6 flex items-center">
        <div className={`rounded-full p-3 ${color}`}>
          {icon}
        </div>
        <div className="ml-4">
          <p className="text-sm font-medium text-neutral-500">{title}</p>
          {isLoading ? (
            <Skeleton className="h-8 w-12 mt-1" />
          ) : (
            <p className="text-2xl font-semibold">{value}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
