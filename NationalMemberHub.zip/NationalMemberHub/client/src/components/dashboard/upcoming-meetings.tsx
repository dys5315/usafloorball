import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { AvatarGroup } from "@/components/ui/avatar-group";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

interface Meeting {
  id: number;
  title: string;
  description: string;
  startTime: string;
  endTime: string;
  platform: string;
  link: string;
  hostId: number;
  clubId?: number;
  leagueId?: number;
  createdAt: string;
}

interface MeetingWithParticipants extends Meeting {
  participants: {
    id: number;
    firstName: string;
    lastName: string;
  }[];
}

export function UpcomingMeetings() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  
  const { data: meetings, isLoading: isLoadingMeetings } = useQuery<Meeting[]>({
    queryKey: ["/api/meetings/upcoming"],
    queryFn: getQueryFn({ on401: "throw" })
  });
  
  // Load participants for each meeting
  const meetingsWithParticipants = useQuery<MeetingWithParticipants[]>({
    queryKey: ["/api/meetings/with-participants"],
    queryFn: async () => {
      if (!meetings || meetings.length === 0) return [];
      
      const meetingsWithParticipants: MeetingWithParticipants[] = [];
      
      for (const meeting of meetings) {
        const participantsRes = await fetch(`/api/meetings/${meeting.id}/participants`, {
          credentials: "include"
        });
        
        if (participantsRes.ok) {
          const participants = await participantsRes.json();
          meetingsWithParticipants.push({
            ...meeting,
            participants
          });
        } else {
          meetingsWithParticipants.push({
            ...meeting,
            participants: []
          });
        }
      }
      
      return meetingsWithParticipants;
    },
    enabled: !!meetings && meetings.length > 0
  });

  const formatMeetingTime = (start: string, end: string) => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    
    const isToday = new Date().toDateString() === startDate.toDateString();
    const isTomorrow = new Date(new Date().setDate(new Date().getDate() + 1)).toDateString() === startDate.toDateString();
    
    const dayStr = isToday 
      ? "Today" 
      : isTomorrow 
        ? "Tomorrow" 
        : format(startDate, "EEEE, MMM d");
    
    return `${dayStr}, ${format(startDate, "h:mm a")} - ${format(endDate, "h:mm a")}`;
  };

  const handleJoinMeeting = (meeting: Meeting) => {
    window.open(meeting.link, "_blank");
  };

  const isLoading = isLoadingMeetings || meetingsWithParticipants.isLoading;
  const meetingsData = meetingsWithParticipants.data || [];

  return (
    <Card className="h-full">
      <CardHeader className="px-6 py-4 border-b border-neutral-200 flex flex-row items-center justify-between">
        <CardTitle className="text-lg">Upcoming Meetings</CardTitle>
        <Button 
          variant="link" 
          className="text-sm text-primary hover:text-primary-600"
          onClick={() => setLocation("/meetings")}
        >
          View all
        </Button>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <MeetingSkeleton />
        ) : meetingsData.length === 0 ? (
          <div className="text-center py-4 text-neutral-500">
            <p>No upcoming meetings scheduled</p>
            <Button 
              variant="outline" 
              className="mt-2"
              onClick={() => setLocation("/meetings")}
            >
              Schedule a meeting
            </Button>
          </div>
        ) : (
          <ul className="space-y-4">
            {meetingsData.slice(0, 3).map((meeting) => (
              <li key={meeting.id} className="border border-neutral-200 rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium text-neutral-800">{meeting.title}</h3>
                    <p className="text-sm text-neutral-500 mt-1">
                      {formatMeetingTime(meeting.startTime, meeting.endTime)}
                    </p>
                  </div>
                  <Badge variant="outline" className={`
                    ${meeting.platform === 'zoom' ? 'bg-primary-100 text-primary-700' : ''}
                    ${meeting.platform === 'teams' ? 'bg-green-100 text-green-700' : ''}
                    ${meeting.platform === 'google' ? 'bg-blue-100 text-blue-700' : ''}
                  `}>
                    {meeting.platform.charAt(0).toUpperCase() + meeting.platform.slice(1)}
                  </Badge>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <AvatarGroup users={meeting.participants || []} max={4} />
                  <Button 
                    variant="link" 
                    className="text-primary hover:text-primary-600 text-sm font-medium"
                    onClick={() => handleJoinMeeting(meeting)}
                  >
                    Join
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function MeetingSkeleton() {
  return (
    <ul className="space-y-4">
      {[1, 2, 3].map((i) => (
        <li key={i} className="border border-neutral-200 rounded-lg p-4">
          <div className="flex justify-between items-start">
            <div className="w-full">
              <Skeleton className="h-5 w-40 mb-2" />
              <Skeleton className="h-4 w-56" />
            </div>
            <Skeleton className="h-6 w-16" />
          </div>
          <div className="mt-3 flex items-center justify-between">
            <div className="flex -space-x-1">
              <Skeleton className="w-6 h-6 rounded-full" />
              <Skeleton className="w-6 h-6 rounded-full" />
              <Skeleton className="w-6 h-6 rounded-full" />
            </div>
            <Skeleton className="h-8 w-12" />
          </div>
        </li>
      ))}
    </ul>
  );
}
