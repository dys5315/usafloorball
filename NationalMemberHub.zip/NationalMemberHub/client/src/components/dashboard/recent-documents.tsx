import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Download, FileText, FileType } from "lucide-react";
import { useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";

interface Document {
  id: number;
  name: string;
  type: string;
  path: string;
  uploadedById: number;
  clubId?: number;
  leagueId?: number;
  isPublic: boolean;
  uploadedAt: string;
  uploadedBy?: {
    firstName: string;
    lastName: string;
  };
}

export function RecentDocuments() {
  const [, setLocation] = useLocation();
  
  const { data: documents, isLoading } = useQuery<Document[]>({
    queryKey: ["/api/documents"],
    queryFn: getQueryFn({ on401: "throw" })
  });

  // Get uploaded by info for each document
  const documentsWithUploader = useQuery<Document[]>({
    queryKey: ["/api/documents/with-uploader"],
    queryFn: async () => {
      if (!documents || documents.length === 0) return [];
      
      // In a real implementation, we would fetch the user info for each document
      // Here we'll just mock it with the current data
      return documents.map(doc => ({
        ...doc,
        uploadedBy: {
          firstName: "John",
          lastName: "Doe"
        }
      }));
    },
    enabled: !!documents && documents.length > 0
  });

  const getDocumentIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'pdf':
        return <FileType className="text-red-500" />;
      case 'doc':
      case 'docx':
        return <FileText className="text-blue-500" />;
      case 'xls':
      case 'xlsx':
        return <FileText className="text-green-500" />;
      case 'jpg':
      case 'jpeg':
      case 'png':
        return <FileText className="text-purple-500" />;
      default:
        return <FileText className="text-neutral-500" />;
    }
  };

  const formatUpdatedAt = (timestamp: string) => {
    const date = new Date(timestamp);
    return `Updated ${formatDistanceToNow(date, { addSuffix: true })}`;
  };

  const handleDownloadDocument = (document: Document) => {
    window.open(document.path, "_blank");
  };

  const isLoadingFinal = isLoading || documentsWithUploader.isLoading;
  const documentsData = documentsWithUploader.data || [];
  const sortedDocuments = [...(documentsData || [])].sort(
    (a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
  );

  return (
    <Card className="h-full">
      <CardHeader className="px-6 py-4 border-b border-neutral-200 flex flex-row items-center justify-between">
        <CardTitle className="text-lg">Recent Documents</CardTitle>
        <Button 
          variant="link" 
          className="text-sm text-primary hover:text-primary-600"
          onClick={() => setLocation("/documents")}
        >
          View all
        </Button>
      </CardHeader>
      <CardContent className="p-6">
        {isLoadingFinal ? (
          <DocumentSkeleton />
        ) : sortedDocuments.length === 0 ? (
          <div className="text-center py-4 text-neutral-500">
            <p>No documents available</p>
            <Button 
              variant="outline" 
              className="mt-2"
              onClick={() => setLocation("/documents")}
            >
              Upload a document
            </Button>
          </div>
        ) : (
          <ul className="space-y-4">
            {sortedDocuments.slice(0, 4).map((document) => (
              <li 
                key={document.id} 
                className="flex items-center justify-between hover:bg-neutral-50 p-2 rounded-lg transition-colors"
              >
                <div className="flex items-center">
                  <div className="w-10 h-12 bg-neutral-100 rounded border border-neutral-200 flex items-center justify-center text-neutral-500">
                    {getDocumentIcon(document.type)}
                  </div>
                  <div className="ml-4">
                    <h3 className="font-medium text-neutral-800">{document.name}</h3>
                    <p className="text-xs text-neutral-500 mt-1">
                      {formatUpdatedAt(document.uploadedAt)} by {document.uploadedBy?.firstName} {document.uploadedBy?.lastName}
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-neutral-400 hover:text-neutral-600"
                  onClick={() => handleDownloadDocument(document)}
                >
                  <Download className="h-5 w-5" />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function DocumentSkeleton() {
  return (
    <ul className="space-y-4">
      {[1, 2, 3, 4].map((i) => (
        <li key={i} className="flex items-center justify-between p-2">
          <div className="flex items-center">
            <Skeleton className="w-10 h-12 rounded" />
            <div className="ml-4">
              <Skeleton className="h-5 w-48 mb-1" />
              <Skeleton className="h-3 w-40" />
            </div>
          </div>
          <Skeleton className="h-8 w-8 rounded-full" />
        </li>
      ))}
    </ul>
  );
}
