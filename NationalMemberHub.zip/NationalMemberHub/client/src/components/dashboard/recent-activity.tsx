import { useQuery } from "@tanstack/react-query";
import { format, isToday, isYesterday } from "date-fns";
import { getQueryFn } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useLocation } from "wouter";

interface Activity {
  id: number;
  type: string;
  details: any;
  userId: number;
  clubId?: number;
  leagueId?: number;
  createdAt: string;
  user?: {
    id: number;
    firstName: string;
    lastName: string;
    username: string;
  };
}

export function RecentActivity() {
  const [, setLocation] = useLocation();
  
  const { data: activities, isLoading } = useQuery<Activity[]>({
    queryKey: ["/api/activities/recent"],
    queryFn: getQueryFn({ on401: "throw" })
  });

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    
    if (isToday(date)) {
      return `Today at ${format(date, "h:mm a")}`;
    } else if (isYesterday(date)) {
      return `Yesterday at ${format(date, "h:mm a")}`;
    } else {
      return format(date, "MMM d");
    }
  };

  const getActivityText = (activity: Activity) => {
    switch (activity.type) {
      case "document_upload":
        return <>uploaded a document <strong>{activity.details.documentName}</strong></>;
      case "club_create":
        return <>created a new club <strong>{activity.details.clubName}</strong></>;
      case "league_create":
        return <>created a new league <strong>{activity.details.leagueName}</strong></>;
      case "meeting_schedule":
        return <>scheduled a meeting <strong>{activity.details.meetingTitle}</strong></>;
      case "club_member_add":
        return <>added {activity.details.memberName} to a club</>;
      case "team_create":
        return <>created a new team <strong>{activity.details.teamName}</strong></>;
      default:
        return <>performed an action</>;
    }
  };

  const getUserInitials = (user: Activity["user"]) => {
    if (!user) return "?";
    return `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`;
  };

  const getRandomColor = (userId: number) => {
    const colors = [
      "bg-red-200 text-red-700",
      "bg-blue-200 text-blue-700",
      "bg-green-200 text-green-700",
      "bg-yellow-200 text-yellow-700",
      "bg-purple-200 text-purple-700",
      "bg-pink-200 text-pink-700",
      "bg-indigo-200 text-indigo-700",
    ];
    return colors[userId % colors.length];
  };

  return (
    <Card className="h-full">
      <CardHeader className="px-6 py-4 border-b border-neutral-200 flex flex-row items-center justify-between">
        <CardTitle className="text-lg">Recent Activity</CardTitle>
        <Button 
          variant="link" 
          className="text-sm text-primary hover:text-primary-600"
          onClick={() => setLocation("/activities")}
        >
          View all
        </Button>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <ActivitySkeleton />
        ) : (
          <ul className="space-y-4">
            {activities?.map((activity) => (
              <li key={activity.id} className="flex items-start">
                <Avatar className={`w-10 h-10 ${getRandomColor(activity.userId)}`}>
                  <AvatarFallback className="font-medium text-sm">
                    {getUserInitials(activity.user)}
                  </AvatarFallback>
                </Avatar>
                <div className="ml-4">
                  <p className="text-sm text-neutral-800">
                    <span className="font-medium">{activity.user?.firstName} {activity.user?.lastName}</span>{" "}
                    {getActivityText(activity)}
                  </p>
                  <p className="text-xs text-neutral-500 mt-1">
                    {formatTimeAgo(activity.createdAt)}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function ActivitySkeleton() {
  return (
    <ul className="space-y-4">
      {[1, 2, 3, 4].map((i) => (
        <li key={i} className="flex items-start">
          <Skeleton className="w-10 h-10 rounded-full" />
          <div className="ml-4 w-full">
            <Skeleton className="h-4 w-full max-w-[250px] mb-2" />
            <Skeleton className="h-3 w-20" />
          </div>
        </li>
      ))}
    </ul>
  );
}
